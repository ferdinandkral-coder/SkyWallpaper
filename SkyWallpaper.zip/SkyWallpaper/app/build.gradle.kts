plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "at.ferdinand.skywallpaper"
    compileSdk = 34

    defaultConfig {
        applicationId = "at.ferdinand.skywallpaper"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "2.3"
    }

    // Fester Schlüssel im Projekt -> jede neue APK lässt sich über die alte installieren
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Mit dem Debug-Schlüssel signiert, damit die Release-APK direkt installierbar ist
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
