package at.ferdinand.skywallpaper

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Live-Position der ISS (api.wheretheiss.at, kostenlos, ohne Schlüssel).
 * Es werden zwei Zeitpunkte geholt (jetzt und +40 s), damit man die Flugrichtung als Spur zeichnen kann.
 */
object Satellites {

    class SatTrack(
        val name: String,
        val lat: Double, val lon: Double, val altKm: Double,
        val lat2: Double, val lon2: Double, val alt2Km: Double,
        val sunlit: Boolean,
        val time: Long
    )

    /** Blockierend. Gibt null zurück, wenn kein Netz. */
    fun fetchIss(timeMillis: Long = System.currentTimeMillis()): SatTrack? {
        val t1 = timeMillis / 1000
        val t2 = t1 + 40
        val url = URL("https://api.wheretheiss.at/v1/satellites/25544/positions?timestamps=$t1,$t2&units=kilometers")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        return try {
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            if (arr.length() < 2) return null
            val a = arr.getJSONObject(0)
            val b = arr.getJSONObject(1)
            SatTrack(
                "ISS",
                a.getDouble("latitude"), a.getDouble("longitude"), a.getDouble("altitude"),
                b.getDouble("latitude"), b.getDouble("longitude"), b.getDouble("altitude"),
                a.optString("visibility") == "daylight",
                timeMillis
            )
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
