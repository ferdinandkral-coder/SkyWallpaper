package at.ferdinand.skywallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * Zeigt das Hintergrundbild und lässt den Himmel mit Punkten und Linien (Polygon) markieren.
 * Punkte werden in Bildkoordinaten 0..1 gespeichert.
 */
class SkyEditorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var image: Bitmap? = null
        set(value) { field = value; requestLayout(); invalidate() }

    /** Fertig gerenderte Vorschau; wenn gesetzt, wird sie statt des Editors gezeigt. */
    var preview: Bitmap? = null
        set(value) { field = value; invalidate() }

    val points = mutableListOf<PointF>()
    var onChanged: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val imgRect = RectF()
    private var dragIndex = -1
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5AA9FF"); strokeWidth = 2.5f * dp; style = Paint.Style.STROKE
    }
    private val closePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#995AA9FF"); strokeWidth = 2f * dp; style = Paint.Style.STROKE
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(8 * dp, 6 * dp), 0f)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#405AA9FF"); style = Paint.Style.FILL
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val pointRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E6FD8"); style = Paint.Style.STROKE; strokeWidth = 3f * dp
    }
    private val firstRing = Paint(pointRing).apply { color = Color.parseColor("#FFB25A") }
    private val emptyText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9FB3D1"); textSize = 16 * dp; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val shown = preview ?: image
        if (shown == null) {
            canvas.drawText("Lade zuerst dein Hintergrundbild", width / 2f, height / 2f, emptyText)
            return
        }
        computeImgRect(shown)
        canvas.drawBitmap(shown, null, imgRect, Paint(Paint.FILTER_BITMAP_FLAG))
        if (preview != null) return

        if (points.isEmpty()) return
        val path = Path()
        points.forEachIndexed { i, p ->
            val (x, y) = toView(p)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        if (points.size >= 3) {
            val closed = Path(path).apply { close() }
            canvas.drawPath(closed, fillPaint)
            val (lx, ly) = toView(points.last())
            val (fx, fy) = toView(points.first())
            canvas.drawLine(lx, ly, fx, fy, closePaint)
        }
        canvas.drawPath(path, linePaint)

        points.forEachIndexed { i, p ->
            val (x, y) = toView(p)
            canvas.drawCircle(x, y, 7 * dp, pointPaint)
            canvas.drawCircle(x, y, 7 * dp, if (i == 0) firstRing else pointRing)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (image == null || preview != null) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; moved = false
                dragIndex = findPoint(e.x, e.y)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (hypot(e.x - downX, e.y - downY) > 6 * dp) moved = true
                if (dragIndex >= 0 && moved) {
                    points[dragIndex] = toImage(e.x, e.y)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragIndex >= 0) {
                    if (moved) onChanged?.invoke()
                } else if (!moved) {
                    val np = toImage(e.x, e.y)
                    val seg = findSegment(e.x, e.y)
                    if (seg >= 0) points.add(seg + 1, np) else points.add(np)
                    onChanged?.invoke()
                }
                dragIndex = -1
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragIndex = -1; return true }
        }
        return super.onTouchEvent(e)
    }

    fun undo() { if (points.isNotEmpty()) { points.removeAt(points.size - 1); invalidate(); onChanged?.invoke() } }
    fun clear() { points.clear(); invalidate(); onChanged?.invoke() }

    /** Schließt die Auswahl über den oberen Bildrand (nachdem der Horizont von links nach rechts getippt wurde). */
    fun closeOverTop() {
        if (points.isEmpty()) return
        val last = points.last()
        val first = points.first()
        // rechter Rand -> rechte obere Ecke -> linke obere Ecke -> linker Rand
        if (last.x > 0.001f) points.add(PointF(1f, last.y))
        points.add(PointF(1f, 0f))
        points.add(PointF(0f, 0f))
        if (first.x > 0.001f) points.add(PointF(0f, first.y))
        invalidate(); onChanged?.invoke()
    }

    fun setPoints(list: List<PointF>) { points.clear(); points.addAll(list); invalidate() }

    // ------------------------------------------------------------

    private fun computeImgRect(b: Bitmap) {
        val s = min(width / b.width.toFloat(), height / b.height.toFloat())
        val w = b.width * s
        val h = b.height * s
        imgRect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    private fun toView(p: PointF): Pair<Float, Float> =
        Pair(imgRect.left + p.x * imgRect.width(), imgRect.top + p.y * imgRect.height())

    /** Bildkoordinate, eingerastet am Rand wenn nahe dran. */
    private fun toImage(x: Float, y: Float): PointF {
        var nx = ((x - imgRect.left) / imgRect.width()).coerceIn(0f, 1f)
        var ny = ((y - imgRect.top) / imgRect.height()).coerceIn(0f, 1f)
        val snapX = 14 * dp / imgRect.width()
        val snapY = 14 * dp / imgRect.height()
        if (nx < snapX) nx = 0f
        if (nx > 1f - snapX) nx = 1f
        if (ny < snapY) ny = 0f
        if (ny > 1f - snapY) ny = 1f
        return PointF(nx, ny)
    }

    private fun findPoint(x: Float, y: Float): Int {
        var best = -1
        var bestD = 24 * dp
        points.forEachIndexed { i, p ->
            val (px, py) = toView(p)
            val d = hypot(px - x, py - y)
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    /** Index i, wenn der Tipp nahe an der Linie zwischen Punkt i und i+1 liegt. */
    private fun findSegment(x: Float, y: Float): Int {
        if (points.size < 2) return -1
        var best = -1
        var bestD = 14 * dp
        val n = if (points.size >= 3) points.size else points.size - 1
        for (i in 0 until n) {
            val (ax, ay) = toView(points[i])
            val (bx, by) = toView(points[(i + 1) % points.size])
            val d = distToSegment(x, y, ax, ay, bx, by)
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    private fun distToSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        if (len2 == 0f) return hypot(px - ax, py - ay)
        val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
        return hypot(px - (ax + t * dx), py - (ay + t * dy))
    }
}
