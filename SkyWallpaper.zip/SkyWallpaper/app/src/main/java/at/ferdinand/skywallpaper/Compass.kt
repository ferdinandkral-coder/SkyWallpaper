package at.ferdinand.skywallpaper

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper

/**
 * Liest einmal die Blickrichtung der Handy-Kamera (Rückseite), wenn das Handy aufrecht gehalten wird.
 * Mittelt etwa 1,5 Sekunden lang, damit der Wert ruhig ist.
 */
object Compass {
    fun readOnce(ctx: Context, done: (Int?) -> Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) { done(null); return }

        var sumSin = 0.0
        var sumCos = 0.0
        var count = 0
        val rot = FloatArray(9)
        val remapped = FloatArray(9)
        val orient = FloatArray(3)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rot, e.values)
                // Handy aufrecht: Kamera schaut entlang der -Z-Achse des Geräts
                SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
                SensorManager.getOrientation(remapped, orient)
                val az = orient[0].toDouble()
                sumSin += kotlin.math.sin(az)
                sumCos += kotlin.math.cos(az)
                count++
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        Handler(Looper.getMainLooper()).postDelayed({
            sm.unregisterListener(listener)
            if (count == 0) {
                done(null)
            } else {
                val deg = Math.toDegrees(kotlin.math.atan2(sumSin, sumCos))
                done(((deg.toInt() % 360) + 360) % 360)
            }
        }, 1500)
    }
}
