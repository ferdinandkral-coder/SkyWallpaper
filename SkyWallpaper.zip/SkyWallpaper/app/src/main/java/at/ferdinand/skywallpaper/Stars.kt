package at.ferdinand.skywallpaper

/**
 * Hellste Sterne (J2000): Rektaszension in Stunden, Deklination in Grad, Helligkeit (mag), Farbe.
 * Reicht, um alle bekannten Sternbilder erkennbar darzustellen.
 */
object Stars {
    class Star(val ra: Double, val dec: Double, val mag: Float, val color: Int)

    private const val W = 0xFFFFFF   // weiß
    private const val B = 0xC8D8FF   // bläulich
    private const val Y = 0xFFF0D0   // gelblich
    private const val O = 0xFFD2A0   // orange
    private const val R = 0xFFB088   // rötlich

    val list: List<Star> = listOf(
        // --- Große Hunde, Kleiner Hund, Orion, Stier, Zwillinge, Fuhrmann (Winterhimmel) ---
        Star(6.752, -16.72, -1.46f, B),  // Sirius
        Star(6.378, -17.96, 1.98f, B),   // Mirzam
        Star(7.140, -26.39, 1.83f, Y),   // Wezen
        Star(6.977, -28.97, 1.50f, B),   // Adhara
        Star(7.402, -29.30, 2.45f, B),   // Aludra
        Star(7.655, 5.22, 0.34f, Y),     // Prokyon
        Star(7.453, 8.29, 2.90f, B),     // Gomeisa
        Star(5.919, 7.41, 0.50f, R),     // Beteigeuze
        Star(5.242, -8.20, 0.13f, B),    // Rigel
        Star(5.419, 6.35, 1.64f, B),     // Bellatrix
        Star(5.796, -9.67, 2.07f, B),    // Saiph
        Star(5.603, -1.20, 1.69f, B),    // Alnilam
        Star(5.679, -1.94, 1.77f, B),    // Alnitak
        Star(5.533, -0.30, 2.23f, B),    // Mintaka
        Star(5.585, 9.93, 3.39f, B),     // Meissa
        Star(4.599, 16.51, 0.86f, O),    // Aldebaran
        Star(5.438, 28.61, 1.65f, B),    // Elnath
        Star(3.791, 24.11, 2.87f, B),    // Alkyone (Plejaden)
        Star(3.763, 24.37, 3.70f, B),    // Atlas
        Star(3.749, 24.11, 3.62f, B),    // Elektra
        Star(3.772, 23.95, 3.87f, B),    // Maia
        Star(3.820, 24.05, 3.80f, B),    // Merope
        Star(4.477, 15.87, 3.53f, O),    // Hyaden ε Tau
        Star(4.330, 15.63, 3.65f, O),    // Hyaden γ Tau
        Star(5.627, 21.14, 3.00f, B),    // ζ Tau
        Star(7.755, 28.03, 1.14f, O),    // Pollux
        Star(7.577, 31.89, 1.58f, W),    // Kastor
        Star(6.629, 16.40, 1.93f, W),    // Alhena
        Star(6.383, 22.51, 2.88f, R),    // Tejat
        Star(6.732, 25.13, 2.98f, Y),    // Mebsuta
        Star(7.335, 21.98, 3.53f, Y),    // Wasat
        Star(5.278, 46.00, 0.08f, Y),    // Kapella
        Star(5.992, 44.95, 1.90f, W),    // Menkalinan
        Star(5.995, 37.21, 2.65f, W),    // θ Aur
        Star(4.950, 33.17, 2.69f, O),    // ι Aur
        Star(5.033, 43.82, 2.99f, W),    // ε Aur

        // --- Perseus, Andromeda, Kassiopeia, Pegasus, Widder ---
        Star(3.405, 49.86, 1.79f, Y),    // Mirfak
        Star(3.136, 40.96, 2.12f, B),    // Algol
        Star(3.715, 47.79, 3.01f, B),    // δ Per
        Star(3.964, 40.01, 2.89f, B),    // ε Per
        Star(3.080, 53.51, 2.91f, Y),    // γ Per
        Star(0.140, 29.09, 2.06f, B),    // Alpheratz
        Star(1.162, 35.62, 2.05f, R),    // Mirach
        Star(2.065, 42.33, 2.10f, O),    // Alamak
        Star(0.656, 30.86, 3.27f, O),    // δ And
        Star(0.675, 56.54, 2.24f, O),    // Schedir
        Star(0.153, 59.15, 2.28f, W),    // Caph
        Star(0.945, 60.72, 2.15f, B),    // γ Cas
        Star(1.430, 60.24, 2.68f, W),    // Ruchbah
        Star(1.907, 63.67, 3.38f, B),    // Segin
        Star(23.063, 28.08, 2.42f, R),   // Scheat
        Star(23.079, 15.21, 2.49f, B),   // Markab
        Star(0.221, 15.18, 2.83f, B),    // Algenib
        Star(21.736, 9.88, 2.39f, O),    // Enif
        Star(22.717, 30.22, 2.94f, Y),   // Matar
        Star(22.691, 10.83, 3.40f, B),   // Homam
        Star(2.120, 23.46, 2.00f, O),    // Hamal
        Star(1.911, 20.81, 2.64f, W),    // Sheratan
        Star(3.038, 4.09, 2.54f, R),     // Menkar
        Star(0.727, -17.99, 2.04f, O),   // Diphda

        // --- Großer & Kleiner Wagen, Drache, Kepheus ---
        Star(11.062, 61.75, 1.79f, O),   // Dubhe
        Star(11.031, 56.38, 2.37f, W),   // Merak
        Star(11.897, 53.69, 2.44f, W),   // Phekda
        Star(12.257, 57.03, 3.31f, W),   // Megrez
        Star(12.900, 55.96, 1.77f, W),   // Alioth
        Star(13.399, 54.93, 2.27f, W),   // Mizar
        Star(13.792, 49.31, 1.86f, B),   // Alkaid
        Star(9.525, 51.68, 3.17f, Y),    // θ UMa
        Star(8.987, 48.04, 3.14f, W),    // Talitha
        Star(10.284, 42.91, 3.45f, W),   // Tania Borealis
        Star(11.161, 44.50, 3.01f, O),   // Alula
        Star(2.530, 89.26, 1.98f, Y),    // Polarstern
        Star(14.845, 74.16, 2.08f, O),   // Kochab
        Star(15.346, 71.83, 3.05f, W),   // Pherkad
        Star(16.766, 82.04, 4.23f, W),   // ε UMi
        Star(17.537, 86.59, 4.36f, W),   // δ UMi
        Star(17.943, 51.49, 2.24f, O),   // Eltanin
        Star(17.507, 52.30, 2.79f, Y),   // Rastaban
        Star(19.209, 67.66, 3.07f, Y),   // Altais
        Star(16.400, 61.51, 2.74f, Y),   // Aldhibah
        Star(14.073, 64.38, 3.65f, W),   // Thuban
        Star(21.310, 62.59, 2.45f, W),   // Alderamin
        Star(23.656, 77.63, 3.21f, O),   // Errai
        Star(21.478, 70.56, 3.23f, B),   // Alfirk

        // --- Löwe, Krebs, Jungfrau, Bärenhüter, Nördliche Krone, Herkules ---
        Star(10.140, 11.97, 1.35f, B),   // Regulus
        Star(11.818, 14.57, 2.14f, W),   // Denebola
        Star(10.333, 19.84, 2.08f, O),   // Algieba
        Star(11.235, 20.52, 2.56f, W),   // Zosma
        Star(11.237, 15.43, 3.33f, W),   // Chertan
        Star(9.764, 23.77, 2.98f, Y),    // ε Leo
        Star(10.278, 23.42, 3.43f, Y),   // Adhafera
        Star(10.122, 16.76, 3.48f, W),   // η Leo
        Star(8.775, 18.15, 3.94f, O),    // Asellus Australis
        Star(13.420, -11.16, 0.97f, B),  // Spika
        Star(12.694, -1.45, 2.74f, W),   // Porrima
        Star(13.036, 10.96, 2.83f, Y),   // Vindemiatrix
        Star(12.927, 3.40, 3.38f, R),    // Minelauva
        Star(14.261, 19.18, -0.05f, O),  // Arktur
        Star(14.750, 27.07, 2.37f, O),   // Izar
        Star(14.535, 38.31, 3.03f, W),   // Seginus
        Star(15.032, 40.39, 3.47f, Y),   // Nekkar
        Star(13.911, 18.40, 2.68f, Y),   // Muphrid
        Star(15.578, 26.71, 2.23f, W),   // Gemma
        Star(15.549, 31.36, 3.66f, Y),   // Nusakan
        Star(16.504, 21.49, 2.78f, Y),   // Kornephoros
        Star(16.688, 31.60, 2.81f, Y),   // ζ Her
        Star(17.005, 30.93, 3.16f, O),   // ε Her
        Star(16.715, 38.92, 3.48f, O),   // η Her
        Star(17.251, 24.84, 3.12f, W),   // Sarin
        Star(17.244, 14.39, 3.10f, R),   // Ras Algethi
        Star(17.582, 12.56, 2.08f, W),   // Ras Alhague
        Star(17.724, 4.57, 2.76f, O),    // Cebalrai

        // --- Sommerdreieck: Leier, Schwan, Adler ---
        Star(18.616, 38.78, 0.03f, B),   // Wega
        Star(18.835, 33.36, 3.52f, B),   // Sheliak
        Star(18.982, 32.69, 3.25f, B),   // Sulafat
        Star(20.690, 45.28, 1.25f, W),   // Deneb
        Star(20.371, 40.26, 2.23f, Y),   // Sadr
        Star(19.512, 27.96, 3.05f, O),   // Albireo
        Star(19.750, 45.13, 2.87f, B),   // Fawaris
        Star(20.770, 33.97, 2.48f, O),   // Aljanah
        Star(19.846, 8.87, 0.77f, W),    // Altair
        Star(19.771, 10.61, 2.72f, O),   // Tarazed
        Star(19.922, 6.41, 3.71f, Y),    // Alshain
        Star(19.090, 13.86, 2.99f, W),   // Deneb el Okab

        // --- Skorpion, Schütze, Waage, Steinbock, Wassermann, Südl. Fisch ---
        Star(16.490, -26.43, 1.06f, R),  // Antares
        Star(17.560, -37.10, 1.62f, B),  // Shaula
        Star(17.622, -43.00, 1.86f, Y),  // Sargas
        Star(16.006, -22.62, 2.29f, B),  // Dschubba
        Star(16.091, -19.81, 2.56f, B),  // Acrab
        Star(15.981, -26.11, 2.89f, B),  // π Sco
        Star(16.836, -34.29, 2.29f, O),  // ε Sco
        Star(17.708, -39.03, 2.39f, B),  // κ Sco
        Star(17.512, -37.30, 2.70f, B),  // Lesath
        Star(18.403, -34.38, 1.85f, B),  // Kaus Australis
        Star(18.921, -26.30, 2.05f, B),  // Nunki
        Star(19.044, -29.88, 2.60f, W),  // Ascella
        Star(18.350, -29.83, 2.70f, O),  // Kaus Media
        Star(18.466, -25.42, 2.81f, O),  // Kaus Borealis
        Star(18.097, -30.42, 2.98f, O),  // Alnasl
        Star(18.229, -36.76, 3.10f, O),  // Kaus? η Sgr
        Star(14.848, -16.04, 2.75f, W),  // Zubenelgenubi
        Star(15.283, -9.38, 2.61f, B),   // Zubeneschamali
        Star(21.784, -16.13, 2.85f, W),  // Deneb Algedi
        Star(20.350, -14.78, 3.05f, Y),  // Dabih
        Star(22.097, -0.32, 2.95f, Y),   // Sadalmelik
        Star(21.526, -5.57, 2.90f, Y),   // Sadalsuud
        Star(22.911, -15.82, 3.27f, W),  // Skat
        Star(22.961, -29.62, 1.16f, W),  // Fomalhaut

        // --- Südhimmel (für Reisen) ---
        Star(6.399, -52.70, -0.74f, W),  // Canopus
        Star(14.660, -60.84, -0.27f, Y), // α Centauri
        Star(14.064, -60.37, 0.61f, B),  // Hadar
        Star(12.443, -63.10, 0.77f, B),  // Acrux
        Star(12.795, -59.69, 1.25f, B),  // Mimosa
        Star(12.519, -57.11, 1.59f, R),  // Gacrux
        Star(12.252, -58.75, 2.79f, B),  // δ Cru
        Star(1.629, -57.24, 0.46f, B),   // Achernar
        Star(9.220, -69.72, 1.67f, W),   // Miaplacidus
        Star(8.159, -47.34, 1.83f, B),   // Regor
        Star(9.133, -43.43, 2.21f, O),   // Suhail
        Star(8.060, -40.00, 2.25f, B),   // Naos
        Star(20.427, -56.74, 1.94f, B),  // Peacock
        Star(22.137, -46.96, 1.74f, B),  // Alnair
        Star(9.460, -8.66, 1.98f, O)     // Alphard
    )
}
