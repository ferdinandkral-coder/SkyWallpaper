package at.ferdinand.skywallpaper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Aktuelles Wetter von Open-Meteo (kostenlos, kein API-Schlüssel nötig). */
data class Weather(
    val code: Int,          // WMO-Wettercode
    val cloudCover: Int,    // 0..100 %
    val temperature: Double,
    val precipitation: Double,
    val windSpeed: Double,
    val fetchedAt: Long
) {
    val isFog get() = code == 45 || code == 48
    val isDrizzle get() = code in 51..57
    val isRain get() = code in 61..67 || code in 80..82
    val isSnow get() = code in 71..77 || code == 85 || code == 86
    val isThunder get() = code >= 95

    fun description(): String = when (code) {
        0 -> "Klar"
        1 -> "Überwiegend klar"
        2 -> "Teilweise bewölkt"
        3 -> "Bedeckt"
        45, 48 -> "Nebel"
        in 51..55 -> "Nieselregen"
        56, 57 -> "Gefrierender Niesel"
        in 61..65 -> "Regen"
        66, 67 -> "Gefrierender Regen"
        in 71..75 -> "Schneefall"
        77 -> "Schneegriesel"
        in 80..82 -> "Regenschauer"
        85, 86 -> "Schneeschauer"
        95 -> "Gewitter"
        96, 99 -> "Gewitter mit Hagel"
        else -> "Wetter $code"
    }

    fun toStorageString() =
        "$code|$cloudCover|$temperature|$precipitation|$windSpeed|$fetchedAt"

    companion object {
        fun fromString(s: String?): Weather? {
            if (s.isNullOrBlank()) return null
            return try {
                val p = s.split("|")
                Weather(p[0].toInt(), p[1].toInt(), p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toLong())
            } catch (e: Exception) {
                null
            }
        }

        /** Blockierender Netzwerkaufruf – nicht im UI-Thread verwenden. */
        fun fetch(lat: Double, lon: Double): Weather {
            val url = URL(
                String.format(
                    Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f" +
                        "&current=temperature_2m,weather_code,cloud_cover,precipitation,wind_speed_10m",
                    lat, lon
                )
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            try {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(text).getJSONObject("current")
                return Weather(
                    code = cur.optInt("weather_code", 0),
                    cloudCover = cur.optInt("cloud_cover", 0),
                    temperature = cur.optDouble("temperature_2m", 0.0),
                    precipitation = cur.optDouble("precipitation", 0.0),
                    windSpeed = cur.optDouble("wind_speed_10m", 0.0),
                    fetchedAt = System.currentTimeMillis()
                )
            } finally {
                conn.disconnect()
            }
        }
    }
}
