package at.ferdinand.skywallpaper

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Positionen von Sonne, Mond, Planeten und Sternen am Himmel (Höhe/Azimut).
 * Verfahren nach Paul Schlyter ("How to compute planetary positions"), Genauigkeit ~1°.
 */
object Astro {
    private const val R = Math.PI / 180.0

    /** Höhe über Horizont und Azimut (0 = Nord, 90 = Ost) in Grad. */
    data class Pos(val alt: Double, val az: Double)

    class Body(val name: String, val pos: Pos, val mag: Float, val color: Int)

    class MoonInfo(val pos: Pos, val illum: Double, val distEarthRadii: Double)

    private fun rev(x: Double) = ((x % 360.0) + 360.0) % 360.0

    /** Tage seit 2000-01-00 0:00 UT (Schlyter). */
    fun dayNumber(timeMillis: Long): Double = timeMillis / 86_400_000.0 + 2440587.5 - 2451543.5

    private fun kepler(m: Double, e: Double): Double {
        var ee = m + e * (180 / Math.PI) * sin(m * R) * (1 + e * cos(m * R))
        repeat(5) {
            ee -= (ee - e * (180 / Math.PI) * sin(ee * R) - m) / (1 - e * cos(ee * R))
        }
        return ee
    }

    /** Sonne: ekliptikale Länge, Abstand (AE), mittlere Anomalie, mittlere Länge. */
    private fun sunRaw(d: Double): DoubleArray {
        val w = 282.9404 + 4.70935e-5 * d
        val e = 0.016709 - 1.151e-9 * d
        val m = rev(356.0470 + 0.9856002585 * d)
        val ea = kepler(m, e)
        val xv = cos(ea * R) - e
        val yv = sqrt(1 - e * e) * sin(ea * R)
        val v = atan2(yv, xv) / R
        return doubleArrayOf(rev(v + w), hypot(xv, yv), m, rev(m + w))
    }

    private fun helio(n: Double, i: Double, w: Double, a: Double, e: Double, m: Double): DoubleArray {
        val ea = kepler(rev(m), e)
        val xv = a * (cos(ea * R) - e)
        val yv = a * sqrt(1 - e * e) * sin(ea * R)
        val v = atan2(yv, xv) / R
        val r = hypot(xv, yv)
        val vw = (v + w) * R
        val x = r * (cos(n * R) * cos(vw) - sin(n * R) * sin(vw) * cos(i * R))
        val y = r * (sin(n * R) * cos(vw) + cos(n * R) * sin(vw) * cos(i * R))
        val z = r * sin(vw) * sin(i * R)
        return doubleArrayOf(x, y, z)
    }

    /** Ekliptik (Länge, Breite) -> Äquator (RA in Grad, Dek in Grad). */
    private fun eclToEq(lon: Double, lat: Double, d: Double): DoubleArray {
        val ecl = (23.4393 - 3.563e-7 * d) * R
        val x = cos(lon * R) * cos(lat * R)
        val y = sin(lon * R) * cos(lat * R)
        val z = sin(lat * R)
        val ye = y * cos(ecl) - z * sin(ecl)
        val ze = y * sin(ecl) + z * cos(ecl)
        return doubleArrayOf(rev(atan2(ye, x) / R), atan2(ze, hypot(x, ye)) / R)
    }

    /** RA/Dek (Grad) -> Höhe/Azimut für Beobachter. */
    fun altAz(raDeg: Double, decDeg: Double, lat: Double, lon: Double, d: Double): Pos {
        val n = d + 2451543.5 - 2451545.0
        val gmst = rev(280.46061837 + 360.98564736629 * n)
        val h = (gmst + lon - raDeg) * R
        val f = lat * R
        val de = decDeg * R
        val alt = asin(sin(f) * sin(de) + cos(f) * cos(de) * cos(h))
        val az = atan2(-sin(h) * cos(de), cos(f) * sin(de) - sin(f) * cos(de) * cos(h))
        return Pos(alt / R, rev(az / R))
    }

    fun sun(lat: Double, lon: Double, timeMillis: Long): Pos {
        val d = dayNumber(timeMillis)
        val s = sunRaw(d)
        val eq = eclToEq(s[0], 0.0, d)
        return altAz(eq[0], eq[1], lat, lon, d)
    }

    fun moon(lat: Double, lon: Double, timeMillis: Long): MoonInfo {
        val d = dayNumber(timeMillis)
        val nn = 125.1228 - 0.0529538083 * d
        val ww = 318.0634 + 0.1643573223 * d
        val mm = rev(115.3654 + 13.0649929509 * d)
        val h = helio(nn, 5.1454, ww, 60.2666, 0.0549, mm)
        var mlon = atan2(h[1], h[0]) / R
        var mlat = atan2(h[2], hypot(h[0], h[1])) / R
        var r = sqrt(h[0] * h[0] + h[1] * h[1] + h[2] * h[2])

        val s = sunRaw(d)
        val ms = s[2]
        val ls = s[3]
        val lm = rev(nn + ww + mm)
        val dd = lm - ls
        val ff = lm - nn
        fun sn(x: Double) = sin(x * R)
        fun cs(x: Double) = cos(x * R)
        mlon += -1.274 * sn(mm - 2 * dd) + 0.658 * sn(2 * dd) - 0.186 * sn(ms) -
            0.059 * sn(2 * mm - 2 * dd) - 0.057 * sn(mm - 2 * dd + ms) + 0.053 * sn(mm + 2 * dd) +
            0.046 * sn(2 * dd - ms) + 0.041 * sn(mm - ms) - 0.035 * sn(dd) - 0.031 * sn(mm + ms) -
            0.015 * sn(2 * ff - 2 * dd) + 0.011 * sn(mm - 4 * dd)
        mlat += -0.173 * sn(ff - 2 * dd) - 0.055 * sn(mm - ff - 2 * dd) - 0.046 * sn(mm + ff - 2 * dd) +
            0.033 * sn(ff + 2 * dd) + 0.017 * sn(2 * mm + ff)
        r += -0.58 * cs(mm - 2 * dd) - 0.46 * cs(2 * dd)
        mlon = rev(mlon)

        // Beleuchteter Anteil aus Elongation zur Sonne
        val elong = Math.acos((cos((s[0] - mlon) * R) * cos(mlat * R)).coerceIn(-1.0, 1.0))
        val illum = (1 - cos(elong)) / 2

        val eq = eclToEq(mlon, mlat, d)
        val geo = altAz(eq[0], eq[1], lat, lon, d)
        // Parallaxe: Mond steht von der Erdoberfläche aus gesehen etwas tiefer
        val par = asin(1.0 / r) / R
        val alt = geo.alt - par * cos(geo.alt * R)
        return MoonInfo(Pos(alt, geo.az), illum, r)
    }

    private class Planet(
        val name: String, val mag: Float, val color: Int,
        val el: (Double) -> DoubleArray
    )

    private val planets = listOf(
        Planet("Venus", -4.2f, 0xFFFBEA) { d ->
            doubleArrayOf(76.6799 + 2.46590e-5 * d, 3.3946 + 2.75e-8 * d, 54.8910 + 1.38374e-5 * d,
                0.723330, 0.006773 - 1.302e-9 * d, 48.0052 + 1.6021302244 * d)
        },
        Planet("Mars", 0.6f, 0xFFB080) { d ->
            doubleArrayOf(49.5574 + 2.11081e-5 * d, 1.8497 - 1.78e-8 * d, 286.5016 + 2.92961e-5 * d,
                1.523688, 0.093405 + 2.516e-9 * d, 18.6021 + 0.5240207766 * d)
        },
        Planet("Jupiter", -2.3f, 0xFFF2DC) { d ->
            doubleArrayOf(100.4542 + 2.76854e-5 * d, 1.3030 - 1.557e-7 * d, 273.8777 + 1.64505e-5 * d,
                5.20256, 0.048498 + 4.469e-9 * d, 19.8950 + 0.0830853001 * d)
        },
        Planet("Saturn", 0.6f, 0xFFE6B8) { d ->
            doubleArrayOf(113.6634 + 2.38980e-5 * d, 2.4886 - 1.081e-7 * d, 339.3939 + 2.97661e-5 * d,
                9.55475, 0.055546 - 9.499e-9 * d, 316.9670 + 0.0334442282 * d)
        }
    )

    fun planets(lat: Double, lon: Double, timeMillis: Long): List<Body> {
        val d = dayNumber(timeMillis)
        val s = sunRaw(d)
        return planets.map { p ->
            val e = p.el(d)
            val h = helio(e[0], e[1], e[2], e[3], e[4], e[5])
            val x = h[0] + s[1] * cos(s[0] * R)
            val y = h[1] + s[1] * sin(s[0] * R)
            val plon = rev(atan2(y, x) / R)
            val plat = atan2(h[2], hypot(x, y)) / R
            val eq = eclToEq(plon, plat, d)
            Body(p.name, altAz(eq[0], eq[1], lat, lon, d), p.mag, p.color)
        }
    }

    fun stars(lat: Double, lon: Double, timeMillis: Long): List<Body> {
        val d = dayNumber(timeMillis)
        return Stars.list.map { st ->
            Body("", altAz(st.ra * 15.0, st.dec, lat, lon, d), st.mag, st.color)
        }
    }

    /** Position eines Satelliten (aus Breite/Länge/Höhe) vom Beobachter aus gesehen. */
    fun satellitePos(obsLat: Double, obsLon: Double, satLat: Double, satLon: Double, satAltKm: Double): Pos {
        val re = 6371.0
        fun ecef(la: Double, lo: Double, r: Double) = doubleArrayOf(
            r * cos(la * R) * cos(lo * R), r * cos(la * R) * sin(lo * R), r * sin(la * R)
        )
        val o = ecef(obsLat, obsLon, re)
        val s = ecef(satLat, satLon, re + satAltKm)
        val dx = s[0] - o[0]; val dy = s[1] - o[1]; val dz = s[2] - o[2]
        val f = obsLat * R; val l = obsLon * R
        val east = -sin(l) * dx + cos(l) * dy
        val north = -sin(f) * cos(l) * dx - sin(f) * sin(l) * dy + cos(f) * dz
        val up = cos(f) * cos(l) * dx + cos(f) * sin(l) * dy + sin(f) * dz
        return Pos(atan2(up, hypot(east, north)) / R, rev(atan2(east, north) / R))
    }
}
