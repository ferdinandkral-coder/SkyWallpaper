package at.ferdinand.skywallpaper

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Sonnenhöhe über dem Horizont (Grad) für Ort und Zeitpunkt. */
object SunCalc {
    private const val RAD = Math.PI / 180.0

    fun elevation(lat: Double, lon: Double, timeMillis: Long): Double {
        val jd = timeMillis / 86_400_000.0 + 2440587.5
        val n = jd - 2451545.0

        val meanLon = mod(280.460 + 0.9856474 * n, 360.0)
        val g = mod(357.528 + 0.9856003 * n, 360.0) * RAD
        val lambda = (meanLon + 1.915 * sin(g) + 0.020 * sin(2 * g)) * RAD
        val eps = (23.439 - 0.0000004 * n) * RAD

        val ra = atan2(cos(eps) * sin(lambda), cos(lambda)) / RAD
        val dec = asin(sin(eps) * sin(lambda))

        val gmst = mod(18.697374558 + 24.06570982441908 * n, 24.0)
        val ha = (gmst * 15.0 + lon - ra) * RAD
        val phi = lat * RAD

        return asin(sin(phi) * sin(dec) + cos(phi) * cos(dec) * cos(ha)) / RAD
    }

    /** Wird die Sonne gerade höher (Vormittag) oder tiefer (Nachmittag)? */
    fun isRising(lat: Double, lon: Double, timeMillis: Long): Boolean =
        elevation(lat, lon, timeMillis + 600_000) > elevation(lat, lon, timeMillis)

    private fun mod(a: Double, b: Double): Double = ((a % b) + b) % b
}
