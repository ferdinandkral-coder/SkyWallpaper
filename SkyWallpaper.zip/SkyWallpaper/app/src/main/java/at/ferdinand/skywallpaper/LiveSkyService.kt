package at.ferdinand.skywallpaper

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Ein Regentropfen bzw. eine Schneeflocke. */
private class Drop(
    var x: Float, var y: Float, var len: Float, var speed: Float, var bucket: Int, var phase: Float
)

/** Sternkatalog für den Zeitraffer: echte helle Sterne + Planeten + schwache Hintergrundsterne. */
private class StarCat(
    val ra: DoubleArray, val sinDec: DoubleArray, val cosDec: DoubleArray,
    val bucket: IntArray, val count: Int
)

/** Ein (erfundenes) Flugzeug mit Kondensstreifen. */
private class Plane(
    var x: Float, var y: Float, val vx: Float, val vy: Float, val size: Float,
    val trail: ArrayList<FloatArray> = ArrayList(), var lastTrail: Long = 0L
)

/**
 * Live-Hintergrund: Wolken ziehen mit der echten Windgeschwindigkeit, Regen fällt,
 * Schnee rieselt, bei Gewitter blitzt es. Alles andere (Himmel, Sonne, Mond, Sterne,
 * Einfärbung) wird alle 15 Minuten bzw. bei Wetteränderung neu berechnet.
 */
class LiveSkyService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private val main = Handler(Looper.getMainLooper())
        private val workerThread = HandlerThread("sky-render").apply { start() }
        private val worker = Handler(workerThread.looper)
        private val store = Store(this@LiveSkyService)
        private val prefs = getSharedPreferences("sky", android.content.Context.MODE_PRIVATE)

        private var width = 0
        private var height = 0
        private var visible = false

        @Volatile private var base: Bitmap? = null
        @Volatile private var layers: SkyRenderer.LiveLayers? = null
        private var lastBuild = 0L
        private var issVisible = false

        // Niederschlag
        private val drops = ArrayList<Drop>()
        private var lastFrame = 0L
        private val startTime = SystemClock.elapsedRealtime()

        // Sternen-Zeitraffer
        @Volatile private var stars: StarCat? = null
        private var starTL = true
        private var lat = 48.2
        private var lon = 16.4
        private var buildWallMs = 0L
        private var headBuf = Array(4) { FloatArray(0) }
        private var trailBuf = Array(4) { Array(3) { FloatArray(0) } }
        private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; color = Color.WHITE }

        // Flugzeuge
        private var planesOn = true
        private val planes = ArrayList<Plane>()
        private var nextPlane = 0L
        private val planePath = android.graphics.Path().apply {
            // Silhouette in Flugrichtung +x, Länge 1
            moveTo(0.5f, 0f); lineTo(0.36f, -0.05f); lineTo(-0.45f, -0.05f); lineTo(-0.5f, 0f)
            lineTo(-0.45f, 0.05f); lineTo(0.36f, 0.05f); close()
            moveTo(0.12f, -0.04f); lineTo(-0.12f, -0.55f); lineTo(-0.22f, -0.55f); lineTo(-0.06f, -0.04f); close()
            moveTo(0.12f, 0.04f); lineTo(-0.12f, 0.55f); lineTo(-0.22f, 0.55f); lineTo(-0.06f, 0.04f); close()
            moveTo(-0.38f, -0.04f); lineTo(-0.47f, -0.22f); lineTo(-0.52f, -0.22f); lineTo(-0.46f, -0.03f); close()
            moveTo(-0.38f, 0.04f); lineTo(-0.47f, 0.22f); lineTo(-0.52f, 0.22f); lineTo(-0.46f, 0.03f); close()
        }
        private val planePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }

        // Blitz
        private var nextFlash = 0L
        private var flashStart = 0L

        private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        private val rainPaints = Array(3) { i ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; alpha = 45 + 30 * i }
        }
        private val snowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lineBuf = FloatArray(0)

        private val frameRunnable = Runnable { drawFrame() }
        private val rebuildTimer = Runnable { requestRebuild(fetch = true) }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            main.removeCallbacksAndMessages(null)
            worker.removeCallbacksAndMessages(null)
            workerThread.quitSafely()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            width = w
            height = h
            drops.clear()
            requestRebuild(fetch = false)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                // Beim Einschalten des Bildschirms: veraltet? -> neu berechnen
                val age = System.currentTimeMillis() - lastBuild
                if (age > 10 * 60_000L) requestRebuild(fetch = true)
                lastFrame = 0L
                scheduleFrame(0)
            } else {
                main.removeCallbacks(frameRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            main.removeCallbacks(frameRunnable)
            super.onSurfaceDestroyed(holder)
        }

        /** Einstellungen oder Wetter in der App geändert -> neu berechnen. */
        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key == null || key in ignoredKeys) return
            // Wetter nur neu zeichnen, wenn es sich wirklich geändert hat
            if (key == "weather" && weatherCore(prefs.getString("weather", null)) == builtWeather) return
            main.removeCallbacks(debouncedRebuild)
            main.postDelayed(debouncedRebuild, 400)
        }
        private val debouncedRebuild = Runnable { requestRebuild(fetch = false) }
        private val ignoredKeys = setOf("lastKey", "preset", "lat", "lon", "hasLoc", "auto", "lock")
        @Volatile private var builtWeather: String? = null
        private fun weatherCore(s: String?) = s?.substringBeforeLast('|')

        // ------------------------------------------------------------------
        // Grundbild berechnen (im Hintergrund-Thread)
        // ------------------------------------------------------------------

        private fun requestRebuild(fetch: Boolean) {
            if (width <= 0 || height <= 0) return
            val w = width
            val h = height
            worker.removeCallbacksAndMessages(null)
            worker.post {
                try { build(w, h, fetch) } catch (t: Throwable) { /* nächster Versuch beim Timer */ }
            }
            main.removeCallbacks(rebuildTimer)
        }

        private fun build(w: Int, h: Int, fetch: Boolean) {
            val original = store.loadOriginal() ?: return

            if (fetch) {
                Updater.lastKnownLocation(this@LiveSkyService)?.let { store.saveLocation(it.first, it.second) }
                try { store.cachedWeather = Weather.fetch(store.lat, store.lon) } catch (e: Exception) { }
            }
            val now = System.currentTimeMillis()
            val sunAlt = Astro.sun(store.lat, store.lon, now).alt
            val iss = if (sunAlt < -4) Satellites.fetchIss(now) else null
            issVisible = iss != null && iss.sunlit &&
                Astro.satellitePos(store.lat, store.lon, iss.lat, iss.lon, iss.altKm).alt > 8

            // Bild auf Bildschirmgröße zuschneiden (wie "Füllen"), Himmelsform mit umrechnen
            val s = max(w / original.width.toFloat(), h / original.height.toFloat())
            val sw = original.width * s
            val sh = original.height * s
            val offX = (sw - w) / 2f
            val offY = (sh - h) / 2f
            val fitted = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(fitted).drawBitmap(original, null,
                RectF(-offX, -offY, sw - offX, sh - offY), Paint(Paint.FILTER_BITMAP_FLAG))
            original.recycle()
            val poly = store.polygon.map { p ->
                PointF((p.x * sw - offX) / w, (p.y * sh - offY) / h)
            }

            builtWeather = weatherCore(prefs.getString("weather", null))
            val scene = Updater.buildScene(store, store.cachedWeather, now, iss)
            val newLayers = SkyRenderer.LiveLayers()
            val wantStars = store.starTimelapse
            newLayers.wantLiveStars = wantStars
            val newStars = if (wantStars) buildCatalog(now) else null
            val newPlanes = store.planes
            val newLat = store.lat
            val newLon = store.lon
            val newBase = SkyRenderer.render(
                fitted, poly, scene, store.softness, store.structure, store.haze, store.keepColors, newLayers, store.cloudOpacity, store.starsAlways
            )
            fitted.recycle()

            main.post {
                val oldBase = base
                val oldLayers = layers
                base = newBase
                layers = newLayers
                stars = newStars
                starTL = wantStars
                planesOn = newPlanes
                lat = newLat
                lon = newLon
                buildWallMs = now
                if (!newPlanes) planes.clear()
                lastBuild = System.currentTimeMillis()
                if (newLayers.rain != oldLayers?.rain || newLayers.snow != oldLayers?.snow) drops.clear()
                oldBase?.recycle()
                oldLayers?.recycle()
                // nächste Neuberechnung: während ISS-Überflug jede Minute, sonst alle 15 min
                main.removeCallbacks(rebuildTimer)
                main.postDelayed(rebuildTimer, if (issVisible) 60_000L else 15 * 60_000L)
                if (visible) scheduleFrame(0)
            }
        }

        // ------------------------------------------------------------------
        // Animation
        // ------------------------------------------------------------------

        private fun scheduleFrame(delay: Long) {
            main.removeCallbacks(frameRunnable)
            if (visible) main.postDelayed(frameRunnable, delay)
        }

        private fun drawFrame() {
            val b = base ?: return
            val l = layers
            val holder = surfaceHolder
            val locked: Canvas? = try {
                holder.lockHardwareCanvas()
            } catch (e: Exception) {
                try { holder.lockCanvas() } catch (e2: Exception) { null }
            }
            val canvas: Canvas = locked ?: return

            val now = SystemClock.elapsedRealtime()
            val dt = if (lastFrame == 0L) 0f else ((now - lastFrame) / 1000f).coerceAtMost(0.1f)
            lastFrame = now
            val t = (now - startTime) / 1000f

            try {
                canvas.drawBitmap(b, 0f, 0f, null)
                if (l != null) {
                    drawSkyLayer(canvas, l, t, dt, now - startTime)
                    if (l.rain) drawRain(canvas, l, dt)
                    if (l.snow) drawSnow(canvas, l, dt, t)
                    if (l.thunder) drawFlash(canvas, now)
                }
            } finally {
                try { holder.unlockCanvasAndPost(canvas) } catch (e: Exception) { }
            }

            // Bildrate: Regen/Schnee flüssig, Wolken gemächlich, sonst Standbild (spart Akku)
            val delay = when {
                l == null -> -1L
                l.rain || l.snow || planesActive(l) || planes.isNotEmpty() -> 33L
                starTL && l.starsVisible && stars != null -> 40L
                l.cloudTile != null -> 50L
                else -> -1L
            }
            if (delay > 0) scheduleFrame(delay)
        }

        /** Alles, was im Himmel passiert: Sterne (Zeitraffer), Flugzeuge, Wolken – auf die Himmelsform zugeschnitten. */
        private fun drawSkyLayer(c: Canvas, l: SkyRenderer.LiveLayers, t: Float, dt: Float, nowMs: Long) {
            val r = l.skyRect
            if (r.width() < 2f || r.height() < 2f) return
            val save = c.saveLayerAlpha(r, l.cloudAlpha)
            c.clipRect(r)
            val showStars = starTL && l.starsVisible
            if (showStars && !l.starsOverClouds) drawStarTimelapse(c, l, t)
            drawPlanes(c, l, dt, nowMs)
            drawClouds(c, l, t)
            if (showStars && l.starsOverClouds) drawStarTimelapse(c, l, t)
            l.mask?.let { c.drawBitmap(it, 0f, 0f, maskPaint) }
            c.restoreToCount(save)
        }

        private fun drawClouds(c: Canvas, l: SkyRenderer.LiveLayers, t: Float) {
            val tile = l.cloudTile ?: return
            val r = l.skyRect
            val tw = r.width()
            // Zeitraffer: bei 10 km/h zieht eine Bildbreite in ~1 Minute vorbei
            val period = (600f / l.windKmh.coerceIn(3f, 80f)).coerceIn(15f, 150f)
            val off = (t / period * tw) % tw
            val dst = RectF(r.left - off, r.top, r.left - off + tw, r.bottom)
            c.drawBitmap(tile, null, dst, bitmapPaint)
            dst.offset(tw, 0f)
            c.drawBitmap(tile, null, dst, bitmapPaint)
        }

        // ------------------------------------------------------------------
        // Sternen-Zeitraffer
        // ------------------------------------------------------------------

        private fun buildCatalog(now: Long): StarCat {
            val ra = ArrayList<Double>()
            val dec = ArrayList<Double>()
            val bk = ArrayList<Int>()
            fun bucketOf(mag: Double) = when {
                mag < 0.5 -> 3
                mag < 2.0 -> 2
                else -> 1
            }
            for (st in Stars.list) { ra.add(st.ra * 15.0); dec.add(st.dec); bk.add(bucketOf(st.mag.toDouble())) }
            for (p in Astro.planetsEq(now)) { ra.add(p[0]); dec.add(p[1]); bk.add(bucketOf(p[2])) }
            // schwache Hintergrundsterne gleichmäßig über die Himmelskugel
            val rnd = Random(4242)
            repeat(700) {
                ra.add(rnd.nextDouble() * 360.0)
                dec.add(Math.toDegrees(kotlin.math.asin(rnd.nextDouble() * 2.0 - 1.0)))
                bk.add(0)
            }
            val n = ra.size
            val sinD = DoubleArray(n) { kotlin.math.sin(Math.toRadians(dec[it])) }
            val cosD = DoubleArray(n) { kotlin.math.cos(Math.toRadians(dec[it])) }
            return StarCat(ra.toDoubleArray(), sinD, cosD, bk.toIntArray(), n)
        }

        private fun drawStarTimelapse(c: Canvas, l: SkyRenderer.LiveLayers, t: Float) {
            val cat = stars ?: return
            val n = cat.count
            if (headBuf[0].size < n * 2) {
                headBuf = Array(4) { FloatArray(n * 2) }
                trailBuf = Array(4) { Array(3) { FloatArray(n * 4) } }
            }
            // 60-s-Schleife: 1 echte Sekunde = 3 Minuten Himmelszeit, weiches Ein-/Ausblenden
            val cycle = 60f
            val ph = t % cycle
            val fade = min(1f, min(ph / 4f, (cycle - ph) / 4f)).coerceAtLeast(0f)
            if (fade <= 0.01f) return
            val simMs = buildWallMs + (ph * 180_000f).toLong()
            val gm = DoubleArray(4) { j -> Astro.gmstDeg(simMs - j * 360_000L) + lon }  // Spur: je 6 min zurück

            val phi = Math.toRadians(lat)
            val sinP = kotlin.math.sin(phi)
            val cosP = kotlin.math.cos(phi)
            val r = l.skyRect
            val margin = r.width() * 0.1f
            val heads = IntArray(4)
            val trails = Array(4) { IntArray(3) }
            val px = FloatArray(4)
            val py = FloatArray(4)

            for (i in 0 until n) {
                val b = cat.bucket[i]
                if (b == 0 && l.bgStars <= 0.01f) continue
                if (b == 1 && l.starLimit < 2.0f) continue
                if (b == 2 && l.starLimit < 0.5f) continue
                var ok = true
                for (j in 0 until 4) {
                    val h = Math.toRadians(gm[j] - cat.ra[i])
                    val cosH = kotlin.math.cos(h)
                    val sinAlt = sinP * cat.sinDec[i] + cosP * cat.cosDec[i] * cosH
                    val alt = Math.toDegrees(kotlin.math.asin(sinAlt.coerceIn(-1.0, 1.0)))
                    if (j == 0 && alt < 1.0) { ok = false; break }
                    val az = Math.toDegrees(kotlin.math.atan2(
                        -kotlin.math.sin(h) * cat.cosDec[i],
                        cosP * cat.sinDec[i] - sinP * cat.cosDec[i] * cosH))
                    val dAz = (((az - l.viewAz) % 360.0 + 540.0) % 360.0) - 180.0
                    px[j] = width / 2f + dAz.toFloat() * l.ppd
                    py[j] = l.horizonY - alt.toFloat() * l.ppdY
                    if (j == 0 && (px[0] < r.left - margin || px[0] > r.right + margin ||
                            py[0] < r.top - margin || py[0] > r.bottom + margin)) { ok = false; break }
                }
                if (!ok) continue
                val hb = headBuf[b]
                hb[heads[b]++] = px[0]; hb[heads[b]++] = py[0]
                for (j in 0 until 3) {
                    // Sprung über den Bildrand (Azimut-Umbruch) nicht als Strich zeichnen
                    if (kotlin.math.abs(px[j] - px[j + 1]) > r.width() * 0.5f) continue
                    val tb = trailBuf[b][j]
                    var k = trails[b][j]
                    tb[k++] = px[j]; tb[k++] = py[j]; tb[k++] = px[j + 1]; tb[k++] = py[j + 1]
                    trails[b][j] = k
                }
            }

            val base = min(width, height).toFloat()
            val size = floatArrayOf(base * 0.0016f, base * 0.0022f, base * 0.0034f, base * 0.0050f)
            val alpha = floatArrayOf(0.45f * l.bgStars, 0.6f, 0.85f, 1f)
            val trailA = floatArrayOf(0.5f, 0.28f, 0.12f)
            for (b in 0 until 4) {
                val a = alpha[b] * fade * l.starAlpha
                if (a <= 0.01f) continue
                for (j in 0 until 3) {
                    if (trails[b][j] == 0) continue
                    starPaint.strokeWidth = size[b] * (0.8f - 0.15f * j)
                    starPaint.alpha = (255 * a * trailA[j]).toInt().coerceIn(0, 255)
                    c.drawLines(trailBuf[b][j], 0, trails[b][j], starPaint)
                }
                if (heads[b] == 0) continue
                starPaint.strokeWidth = size[b] * 1.6f
                starPaint.alpha = (255 * a).toInt().coerceIn(0, 255)
                c.drawPoints(headBuf[b], 0, heads[b], starPaint)
            }
        }

        // ------------------------------------------------------------------
        // Flugzeuge (reine Animation, im Zeitraffer)
        // ------------------------------------------------------------------

        private fun planesActive(l: SkyRenderer.LiveLayers) =
            planesOn && l.dayLight > 0.5f && !l.wet && l.cover < 0.9f

        private fun drawPlanes(c: Canvas, l: SkyRenderer.LiveLayers, dt: Float, nowMs: Long) {
            val r = l.skyRect
            if (planesActive(l) && nowMs >= nextPlane && planes.size < 2) {
                if (nextPlane != 0L) {
                    val dir = if (Random.nextBoolean()) 1f else -1f
                    val speed = r.width() / (7f + Random.nextFloat() * 5f)   // ~7–12 s über den Himmel
                    val ang = (Random.nextFloat() - 0.5f) * 0.4f
                    val y = r.top + r.height() * (0.12f + 0.55f * Random.nextFloat())
                    val sz = r.width() * 0.016f * (0.7f + 0.6f * Random.nextFloat())
                    val x = if (dir > 0) r.left - sz * 2 else r.right + sz * 2
                    planes.add(Plane(x, y, dir * speed * kotlin.math.cos(ang), speed * kotlin.math.sin(ang), sz))
                }
                nextPlane = nowMs + 5000 + Random.nextLong(11000)
            }

            val life = 12_000f
            val tint = lerpColor(0xFFFFFF, 0xFFC9A8, l.golden)
            val iter = planes.iterator()
            while (iter.hasNext()) {
                val p = iter.next()
                p.x += p.vx * dt
                p.y += p.vy * dt
                val inside = p.x > r.left - p.size * 3 && p.x < r.right + p.size * 3
                if (inside && nowMs - p.lastTrail > 60) {
                    val back = 0.55f * p.size / kotlin.math.hypot(p.vx, p.vy).coerceAtLeast(1f)
                    p.trail.add(floatArrayOf(p.x - p.vx * back, p.y - p.vy * back, nowMs.toFloat()))
                    p.lastTrail = nowMs
                }
                while (p.trail.isNotEmpty() && nowMs - p.trail[0][2] > life) p.trail.removeAt(0)
                if (!inside && p.trail.isEmpty()) { iter.remove(); continue }

                // Kondensstreifen: frisch schmal & hell, mit der Zeit breiter & blasser
                for (k in 1 until p.trail.size) {
                    val a = p.trail[k - 1]
                    val b = p.trail[k]
                    val ageNew = nowMs - b[2]
                    if (ageNew < 180) continue                       // kleine Lücke hinter dem Flugzeug
                    val age = ((nowMs - a[2]) / life).coerceIn(0f, 1f)
                    val al = (1f - age) * (1f - age) * 175f * l.dayLight
                    trailPaint.color = (tint and 0xFFFFFF) or (al.toInt().coerceIn(0, 255) shl 24)
                    trailPaint.strokeWidth = p.size * (0.12f + 0.55f * age)
                    c.drawLine(a[0], a[1], b[0], b[1], trailPaint)
                }

                // Silhouette
                if (inside) {
                    c.save()
                    c.translate(p.x, p.y)
                    c.rotate(Math.toDegrees(kotlin.math.atan2(p.vy, p.vx).toDouble()).toFloat())
                    c.scale(p.size, p.size)
                    planePaint.color = Color.argb((220 * l.dayLight).toInt(), 42, 46, 54)
                    c.drawPath(planePath, planePaint)
                    planePaint.color = Color.argb((200 * l.dayLight).toInt(), 255, 255, 255)
                    c.drawCircle(0.2f, -0.02f, 0.05f, planePaint)          // Sonnenreflex
                    c.restore()
                }
            }
        }

        private fun ensureDrops(count: Int, snow: Boolean) {
            if (drops.size == count) return
            drops.clear()
            val rnd = Random(SystemClock.elapsedRealtime())
            repeat(count) {
                drops.add(Drop(
                    rnd.nextFloat() * width * 1.3f - width * 0.15f,
                    rnd.nextFloat() * height,
                    if (snow) min(width, height) * (0.0015f + 0.004f * rnd.nextFloat() * rnd.nextFloat())
                    else height * (0.018f + 0.03f * rnd.nextFloat()),
                    if (snow) height * (0.04f + 0.06f * rnd.nextFloat())
                    else height * (1.1f + 0.9f * rnd.nextFloat()),
                    rnd.nextInt(3),
                    rnd.nextFloat() * 6.28f
                ))
            }
        }

        private fun drawRain(c: Canvas, l: SkyRenderer.LiveLayers, dt: Float) {
            val count = (width * height / 9000f * l.rainIntensity).toInt().coerceIn(60, 900)
            ensureDrops(count, false)
            val slant = (l.windKmh / 40f).coerceIn(0f, 0.6f)
            val col = lerpColor(0xD8E2EE, 0x8090A8, l.night)
            val sw = max(1f, width / 900f)
            if (lineBuf.size < count * 4) lineBuf = FloatArray(count * 4)

            for (bucket in 0 until 3) {
                var n = 0
                for (d in drops) {
                    if (d.bucket != bucket) continue
                    d.y += d.speed * dt
                    d.x -= d.speed * dt * slant
                    if (d.y - d.len > height) {
                        d.y = -d.len * (1f + Random.nextFloat())
                        d.x = Random.nextFloat() * width * 1.3f - width * 0.15f + height * slant * 0.5f
                    }
                    lineBuf[n++] = d.x
                    lineBuf[n++] = d.y
                    lineBuf[n++] = d.x + d.len * slant
                    lineBuf[n++] = d.y - d.len
                }
                val p = rainPaints[bucket]
                p.color = (col and 0xFFFFFF) or ((45 + 30 * bucket) shl 24)
                p.strokeWidth = sw * (0.8f + 0.3f * bucket)
                if (n > 0) c.drawLines(lineBuf, 0, n, p)
            }
        }

        private fun drawSnow(c: Canvas, l: SkyRenderer.LiveLayers, dt: Float, t: Float) {
            val count = (width * height / 7000f).toInt().coerceIn(80, 700)
            ensureDrops(count, true)
            val wind = (l.windKmh / 30f).coerceIn(0f, 1.2f)
            for (d in drops) {
                d.y += d.speed * dt
                d.x += (sin(t * 0.8f + d.phase) * 18f - wind * 40f) * dt * (height / 2000f)
                if (d.y - d.len > height) {
                    d.y = -d.len * 2
                    d.x = Random.nextFloat() * width * 1.3f - width * 0.15f
                }
                snowPaint.color = Color.argb(140 + 40 * d.bucket, 255, 255, 255)
                c.drawCircle(d.x, d.y, d.len, snowPaint)
            }
        }

        private fun drawFlash(c: Canvas, now: Long) {
            if (nextFlash == 0L) nextFlash = now + 4000 + Random.nextLong(12000)
            if (now >= nextFlash) {
                flashStart = now
                nextFlash = now + 6000 + Random.nextLong(18000)
            }
            val age = now - flashStart
            if (flashStart > 0 && age < 450) {
                // zwei kurze Aufhellungen hintereinander, wie bei echtem Blitz
                val k = if (age < 120) 1f - age / 120f else if (age >= 180L && age <= 450L) 0.6f * (1f - (age - 180) / 270f) else 0f
                c.drawColor(Color.argb((110 * k).toInt().coerceIn(0, 255), 225, 230, 255))
            }
        }

        private fun lerpColor(a: Int, b: Int, t: Float): Int {
            val tt = t.coerceIn(0f, 1f)
            val r = ((a shr 16 and 0xFF) + ((b shr 16 and 0xFF) - (a shr 16 and 0xFF)) * tt).toInt()
            val g = ((a shr 8 and 0xFF) + ((b shr 8 and 0xFF) - (a shr 8 and 0xFF)) * tt).toInt()
            val bl = ((a and 0xFF) + ((b and 0xFF) - (a and 0xFF)) * tt).toInt()
            return (r shl 16) or (g shl 8) or bl
        }
    }
}
