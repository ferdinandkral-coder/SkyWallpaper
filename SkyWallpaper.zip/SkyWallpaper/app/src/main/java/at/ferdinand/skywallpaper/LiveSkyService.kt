package at.ferdinand.skywallpaper

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Live-Hintergrund: Wolken ziehen mit der echten Windgeschwindigkeit, Regen fällt,
 * Schnee rieselt, bei Gewitter blitzt es. Alles andere (Himmel, Sonne, Mond, Sterne,
 * Einfärbung) wird alle 15 Minuten bzw. bei Wetteränderung neu berechnet.
 */
class LiveSkyService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private val main = Handler(Looper.getMainLooper())
        private val workerThread = HandlerThread("sky-render").apply { start() }
        private val worker = Handler(workerThread.looper)
        private val store = Store(this@LiveSkyService)
        private val prefs = getSharedPreferences("sky", MODE_PRIVATE)

        private var width = 0
        private var height = 0
        private var visible = false

        @Volatile private var base: Bitmap? = null
        @Volatile private var layers: SkyRenderer.LiveLayers? = null
        private var lastBuild = 0L
        private var issVisible = false

        // Niederschlag
        private class Drop(var x: Float, var y: Float, var len: Float, var speed: Float, var bucket: Int, var phase: Float)
        private val drops = ArrayList<Drop>()
        private var lastFrame = 0L
        private val startTime = SystemClock.elapsedRealtime()

        // Blitz
        private var nextFlash = 0L
        private var flashStart = 0L

        private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        private val rainPaints = Array(3) { i ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; alpha = 45 + 30 * i }
        }
        private val snowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lineBuf = FloatArray(0)

        private val frameRunnable = Runnable { drawFrame() }
        private val rebuildTimer = Runnable { requestRebuild(fetch = true) }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            main.removeCallbacksAndMessages(null)
            worker.removeCallbacksAndMessages(null)
            workerThread.quitSafely()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            width = w
            height = h
            drops.clear()
            requestRebuild(fetch = false)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                // Beim Einschalten des Bildschirms: veraltet? -> neu berechnen
                val age = System.currentTimeMillis() - lastBuild
                if (age > 10 * 60_000L) requestRebuild(fetch = true)
                lastFrame = 0L
                scheduleFrame(0)
            } else {
                main.removeCallbacks(frameRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            main.removeCallbacks(frameRunnable)
            super.onSurfaceDestroyed(holder)
        }

        /** Einstellungen oder Wetter in der App geändert -> neu berechnen. */
        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key in ignoredKeys) return
            // Wetter nur neu zeichnen, wenn es sich wirklich geändert hat
            if (key == "weather" && weatherCore(prefs.getString("weather", null)) == builtWeather) return
            main.removeCallbacks(debouncedRebuild)
            main.postDelayed(debouncedRebuild, 400)
        }
        private val debouncedRebuild = Runnable { requestRebuild(fetch = false) }
        private val ignoredKeys = setOf("lastKey", "preset", "lat", "lon", "hasLoc", "auto", "lock")
        @Volatile private var builtWeather: String? = null
        private fun weatherCore(s: String?) = s?.substringBeforeLast('|')

        // ------------------------------------------------------------------
        // Grundbild berechnen (im Hintergrund-Thread)
        // ------------------------------------------------------------------

        private fun requestRebuild(fetch: Boolean) {
            if (width <= 0 || height <= 0) return
            val w = width
            val h = height
            worker.removeCallbacksAndMessages(null)
            worker.post {
                try { build(w, h, fetch) } catch (t: Throwable) { /* nächster Versuch beim Timer */ }
            }
            main.removeCallbacks(rebuildTimer)
        }

        private fun build(w: Int, h: Int, fetch: Boolean) {
            val original = store.loadOriginal() ?: return

            if (fetch) {
                Updater.lastKnownLocation(this@LiveSkyService)?.let { store.saveLocation(it.first, it.second) }
                try { store.cachedWeather = Weather.fetch(store.lat, store.lon) } catch (e: Exception) { }
            }
            val now = System.currentTimeMillis()
            val sunAlt = Astro.sun(store.lat, store.lon, now).alt
            val iss = if (sunAlt < -4) Satellites.fetchIss(now) else null
            issVisible = iss != null && iss.sunlit &&
                Astro.satellitePos(store.lat, store.lon, iss.lat, iss.lon, iss.altKm).alt > 8

            // Bild auf Bildschirmgröße zuschneiden (wie "Füllen"), Himmelsform mit umrechnen
            val s = max(w / original.width.toFloat(), h / original.height.toFloat())
            val sw = original.width * s
            val sh = original.height * s
            val offX = (sw - w) / 2f
            val offY = (sh - h) / 2f
            val fitted = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(fitted).drawBitmap(original, null,
                RectF(-offX, -offY, sw - offX, sh - offY), Paint(Paint.FILTER_BITMAP_FLAG))
            original.recycle()
            val poly = store.polygon.map { p ->
                PointF((p.x * sw - offX) / w, (p.y * sh - offY) / h)
            }

            builtWeather = weatherCore(prefs.getString("weather", null))
            val scene = Updater.buildScene(store, store.cachedWeather, now, iss)
            val newLayers = SkyRenderer.LiveLayers()
            val newBase = SkyRenderer.render(
                fitted, poly, scene, store.softness, store.structure, store.haze, store.keepColors, newLayers
            )
            fitted.recycle()

            main.post {
                val oldBase = base
                val oldLayers = layers
                base = newBase
                layers = newLayers
                lastBuild = System.currentTimeMillis()
                if (newLayers.rain != oldLayers?.rain || newLayers.snow != oldLayers?.snow) drops.clear()
                oldBase?.recycle()
                oldLayers?.recycle()
                // nächste Neuberechnung: während ISS-Überflug jede Minute, sonst alle 15 min
                main.removeCallbacks(rebuildTimer)
                main.postDelayed(rebuildTimer, if (issVisible) 60_000L else 15 * 60_000L)
                if (visible) scheduleFrame(0)
            }
        }

        // ------------------------------------------------------------------
        // Animation
        // ------------------------------------------------------------------

        private fun scheduleFrame(delay: Long) {
            main.removeCallbacks(frameRunnable)
            if (visible) main.postDelayed(frameRunnable, delay)
        }

        private fun drawFrame() {
            val b = base ?: return
            val l = layers
            val holder = surfaceHolder
            val locked: Canvas? = try {
                holder.lockHardwareCanvas()
            } catch (e: Exception) {
                try { holder.lockCanvas() } catch (e2: Exception) { null }
            }
            val canvas: Canvas = locked ?: return

            val now = SystemClock.elapsedRealtime()
            val dt = if (lastFrame == 0L) 0f else ((now - lastFrame) / 1000f).coerceAtMost(0.1f)
            lastFrame = now
            val t = (now - startTime) / 1000f

            try {
                canvas.drawBitmap(b, 0f, 0f, null)
                if (l != null) {
                    drawClouds(canvas, l, t)
                    if (l.rain) drawRain(canvas, l, dt)
                    if (l.snow) drawSnow(canvas, l, dt, t)
                    if (l.thunder) drawFlash(canvas, now)
                }
            } finally {
                try { holder.unlockCanvasAndPost(canvas) } catch (e: Exception) { }
            }

            // Bildrate: Regen/Schnee flüssig, Wolken gemächlich, sonst Standbild (spart Akku)
            val delay = when {
                l == null -> -1L
                l.rain || l.snow -> 33L
                l.cloudTile != null -> 50L
                else -> -1L
            }
            if (delay > 0) scheduleFrame(delay)
        }

        private fun drawClouds(c: Canvas, l: SkyRenderer.LiveLayers, t: Float) {
            val tile = l.cloudTile ?: return
            val r = l.skyRect
            val tw = r.width()
            if (tw < 2f) return
            // Wind: bei 10 km/h zieht eine Bildbreite in ~4 Minuten vorbei
            val period = (2400f / l.windKmh.coerceIn(3f, 80f)).coerceIn(45f, 600f)
            val off = (t / period * tw) % tw

            val save = c.saveLayerAlpha(r, l.skyAlpha)
            c.clipRect(r)
            val dst = RectF(r.left - off, r.top, r.left - off + tw, r.bottom)
            c.drawBitmap(tile, null, dst, bitmapPaint)
            dst.offset(tw, 0f)
            c.drawBitmap(tile, null, dst, bitmapPaint)
            l.mask?.let { c.drawBitmap(it, 0f, 0f, maskPaint) }
            c.restoreToCount(save)
        }

        private fun ensureDrops(count: Int, snow: Boolean) {
            if (drops.size == count) return
            drops.clear()
            val rnd = Random(SystemClock.elapsedRealtime())
            repeat(count) {
                drops.add(Drop(
                    rnd.nextFloat() * width * 1.3f - width * 0.15f,
                    rnd.nextFloat() * height,
                    if (snow) min(width, height) * (0.0015f + 0.004f * rnd.nextFloat() * rnd.nextFloat())
                    else height * (0.018f + 0.03f * rnd.nextFloat()),
                    if (snow) height * (0.04f + 0.06f * rnd.nextFloat())
                    else height * (1.1f + 0.9f * rnd.nextFloat()),
                    rnd.nextInt(3),
                    rnd.nextFloat() * 6.28f
                ))
            }
        }

        private fun drawRain(c: Canvas, l: SkyRenderer.LiveLayers, dt: Float) {
            val count = (width * height / 9000f * l.rainIntensity).toInt().coerceIn(60, 900)
            ensureDrops(count, false)
            val slant = (l.windKmh / 40f).coerceIn(0f, 0.6f)
            val col = lerpColor(0xD8E2EE, 0x8090A8, l.night)
            val sw = max(1f, width / 900f)
            if (lineBuf.size < count * 4) lineBuf = FloatArray(count * 4)

            for (bucket in 0 until 3) {
                var n = 0
                for (d in drops) {
                    if (d.bucket != bucket) continue
                    d.y += d.speed * dt
                    d.x -= d.speed * dt * slant
                    if (d.y - d.len > height) {
                        d.y = -d.len * (1f + Random.nextFloat())
                        d.x = Random.nextFloat() * width * 1.3f - width * 0.15f + height * slant * 0.5f
                    }
                    lineBuf[n++] = d.x
                    lineBuf[n++] = d.y
                    lineBuf[n++] = d.x + d.len * slant
                    lineBuf[n++] = d.y - d.len
                }
                val p = rainPaints[bucket]
                p.color = (col and 0xFFFFFF) or ((45 + 30 * bucket) shl 24)
                p.strokeWidth = sw * (0.8f + 0.3f * bucket)
                if (n > 0) c.drawLines(lineBuf, 0, n, p)
            }
        }

        private fun drawSnow(c: Canvas, l: SkyRenderer.LiveLayers, dt: Float, t: Float) {
            val count = (width * height / 7000f).toInt().coerceIn(80, 700)
            ensureDrops(count, true)
            val wind = (l.windKmh / 30f).coerceIn(0f, 1.2f)
            for (d in drops) {
                d.y += d.speed * dt
                d.x += (sin(t * 0.8f + d.phase) * 18f - wind * 40f) * dt * (height / 2000f)
                if (d.y - d.len > height) {
                    d.y = -d.len * 2
                    d.x = Random.nextFloat() * width * 1.3f - width * 0.15f
                }
                snowPaint.color = Color.argb(140 + 40 * d.bucket, 255, 255, 255)
                c.drawCircle(d.x, d.y, d.len, snowPaint)
            }
        }

        private fun drawFlash(c: Canvas, now: Long) {
            if (nextFlash == 0L) nextFlash = now + 4000 + Random.nextLong(12000)
            if (now >= nextFlash) {
                flashStart = now
                nextFlash = now + 6000 + Random.nextLong(18000)
            }
            val age = now - flashStart
            if (flashStart > 0 && age < 450) {
                // zwei kurze Aufhellungen hintereinander, wie bei echtem Blitz
                val k = if (age < 120) 1f - age / 120f else if (age in 180..450) 0.6f * (1f - (age - 180) / 270f) else 0f
                c.drawColor(Color.argb((110 * k).toInt().coerceIn(0, 255), 225, 230, 255))
            }
        }

        private fun lerpColor(a: Int, b: Int, t: Float): Int {
            val tt = t.coerceIn(0f, 1f)
            val r = ((a shr 16 and 0xFF) + ((b shr 16 and 0xFF) - (a shr 16 and 0xFF)) * tt).toInt()
            val g = ((a shr 8 and 0xFF) + ((b shr 8 and 0xFF) - (a shr 8 and 0xFF)) * tt).toInt()
            val bl = ((a and 0xFF) + ((b and 0xFF) - (a and 0xFF)) * tt).toInt()
            return (r shl 16) or (g shl 8) or bl
        }
    }
}
