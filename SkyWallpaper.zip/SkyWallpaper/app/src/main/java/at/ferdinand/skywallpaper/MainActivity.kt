package at.ferdinand.skywallpaper

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var editor: SkyEditorView
    private lateinit var txtStatus: TextView
    private lateinit var txtTime: TextView
    private lateinit var seekTime: SeekBar
    private lateinit var previewBar: View
    private lateinit var btnPreview: Button

    private var original: Bitmap? = null
    private var weather: Weather? = null
    private var iss: Satellites.SatTrack? = null
    private var previewOn = false
    private var previewJob = 0

    companion object {
        private const val REQ_LOCATION = 1
        private const val REQ_STORAGE = 2
        private const val REQ_PICK = 3
        private const val MAX_SIDE = 2880
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        editor = findViewById(R.id.editor)
        txtStatus = findViewById(R.id.txtStatus)
        txtTime = findViewById(R.id.txtTime)
        seekTime = findViewById(R.id.seekTime)
        previewBar = findViewById(R.id.previewBar)
        btnPreview = findViewById(R.id.btnPreview)

        applyPresetIfNeeded()
        weather = store.cachedWeather
        editor.setPoints(store.polygon)
        editor.onChanged = { store.polygon = editor.points.toList() }

        thread {
            val bmp = store.loadOriginal()
            runOnUiThread {
                if (bmp != null) {
                    original = bmp
                    editor.image = bmp
                }
            }
        }

        findViewById<Button>(R.id.btnWallpaper).setOnClickListener { loadCurrentWallpaper() }
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickImage() }
        findViewById<Button>(R.id.btnUndo).setOnClickListener { editor.undo() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Alle Punkte löschen?")
                .setPositiveButton("Löschen") { _, _ -> editor.clear() }
                .setNegativeButton("Abbrechen", null)
                .show()
        }
        findViewById<Button>(R.id.btnTop).setOnClickListener { editor.closeOverTop() }
        btnPreview.setOnClickListener { togglePreview() }
        findViewById<Button>(R.id.btnApply).setOnClickListener { applyNow() }
        findViewById<Button>(R.id.btnLive).setOnClickListener { startLive() }

        seekTime.progress = 0
        seekTime.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { renderPreview() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        val seekSoft = findViewById<SeekBar>(R.id.seekSoft)
        val txtSoft = findViewById<TextView>(R.id.txtSoft)
        seekSoft.progress = store.softness
        txtSoft.text = "Übergang ${store.softness} %"
        seekSoft.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtSoft.text = "Übergang $p %"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.softness = sb.progress
                if (previewOn) renderPreview()
            }
        })

        val seekStruct = findViewById<SeekBar>(R.id.seekStruct)
        val txtStruct = findViewById<TextView>(R.id.txtStruct)
        seekStruct.progress = store.structure
        txtStruct.text = "Struktur ${store.structure} %"
        seekStruct.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtStruct.text = "Struktur $p %"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.structure = sb.progress
                if (previewOn) renderPreview()
            }
        })

        val panel = findViewById<View>(R.id.settingsPanel)
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        btnSettings.setOnClickListener {
            val open = panel.visibility != View.VISIBLE
            panel.visibility = if (open) View.VISIBLE else View.GONE
            btnSettings.text = if (open) "⚙ Einstellungen ▴" else "⚙ Einstellungen ▾"
        }

        val seekKeep = findViewById<SeekBar>(R.id.seekKeep)
        val txtKeep = findViewById<TextView>(R.id.txtKeep)
        seekKeep.progress = store.keepColors
        txtKeep.text = "Farben ${store.keepColors} %"
        seekKeep.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtKeep.text = "Farben $p %"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.keepColors = sb.progress
                if (previewOn) renderPreview()
            }
        })

        val seekHaze = findViewById<SeekBar>(R.id.seekHaze)
        val txtHaze = findViewById<TextView>(R.id.txtHaze)
        seekHaze.progress = store.haze
        txtHaze.text = "Dunst ${store.haze} %"
        seekHaze.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtHaze.text = "Dunst $p %"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.haze = sb.progress
                if (previewOn) renderPreview()
            }
        })

        val seekDir = findViewById<SeekBar>(R.id.seekDir)
        val txtDir = findViewById<TextView>(R.id.txtDir)
        seekDir.progress = store.viewAz
        txtDir.text = dirLabel(store.viewAz)
        seekDir.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtDir.text = dirLabel(p)
                editor.viewAz = p.toDouble(); editor.invalidate()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.viewAz = sb.progress
                if (previewOn) renderPreview()
            }
        })
        findViewById<Button>(R.id.btnCompass).setOnClickListener {
            Compass.readOnce(this) { az ->
                if (az == null) {
                    toast("Kein Kompass im Handy gefunden")
                } else {
                    store.viewAz = az
                    seekDir.progress = az
                    toast("Richtung übernommen: ${dirLabel(az)}")
                    if (previewOn) renderPreview()
                }
            }
            toast("Handy aufrecht halten, Kamera in Bildrichtung …")
        }

        val seekFov = findViewById<SeekBar>(R.id.seekFov)
        val txtFov = findViewById<TextView>(R.id.txtFov)
        seekFov.progress = store.hfov - 20
        txtFov.text = "Sichtfeld ${store.hfov}°"
        seekFov.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                txtFov.text = "Sichtfeld ${p + 20}°"
                editor.hfov = (p + 20).toDouble(); editor.invalidate()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                store.hfov = sb.progress + 20
                if (previewOn) renderPreview()
            }
        })
        editor.viewAz = store.viewAz.toDouble()
        editor.hfov = store.hfov.toDouble()

        val swAuto = findViewById<Switch>(R.id.swAuto)
        swAuto.isChecked = store.autoUpdate
        swAuto.setOnCheckedChangeListener { _, on ->
            store.autoUpdate = on
            Updater.schedule(this, on)
            toast(if (on) "Automatische Aktualisierung an" else "Automatische Aktualisierung aus")
        }
        val cbLock = findViewById<CheckBox>(R.id.cbLock)
        cbLock.isChecked = store.alsoLock
        cbLock.setOnCheckedChangeListener { _, on -> store.alsoLock = on; store.lastKey = null }

        if (store.autoUpdate) Updater.schedule(this, true)
        requestLocation()
    }

    // ---------------- Standort & Wetter ----------------

    private fun requestLocation() {
        val granted = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                REQ_LOCATION
            )
            return
        }
        val last = Updater.lastKnownLocation(this)
        if (last != null) {
            store.saveLocation(last.first, last.second)
            fetchWeather()
        } else {
            setStatus("Standort wird ermittelt …")
        }
        requestFreshLocation()
    }

    @SuppressLint("MissingPermission")
    private fun requestFreshLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            if (!store.hasLocation) setStatus("Standort ist aus – bitte in den Einstellungen einschalten")
            fetchWeather()
            return
        }
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(loc: Location) {
                    lm.removeUpdates(this)
                    store.saveLocation(loc.latitude, loc.longitude)
                    fetchWeather()
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            fetchWeather()
        }
    }

    private fun fetchWeather() {
        val lat = store.lat
        val lon = store.lon
        thread {
            val w = try { Weather.fetch(lat, lon) } catch (e: Exception) { null }
            val s = Satellites.fetchIss()
            runOnUiThread {
                if (s != null) iss = s
                if (w != null) {
                    weather = w
                    store.cachedWeather = w
                }
                updateStatus(w == null)
                if (previewOn) renderPreview()
            }
        }
    }

    private fun updateStatus(failed: Boolean = false) {
        val w = weather
        val elev = SunCalc.elevation(store.lat, store.lon, System.currentTimeMillis())
        val loc = if (store.hasLocation) String.format(Locale.GERMANY, "%.2f°, %.2f°", store.lat, store.lon)
                  else "Wien (Standard)"
        val wtxt = if (w != null) String.format(Locale.GERMANY, "%s · %.0f °C · %d %% Wolken", w.description(), w.temperature, w.cloudCover)
                   else "kein Wetter"
        val sun = String.format(Locale.GERMANY, "Sonne %.0f°", elev)
        val now = System.currentTimeMillis()
        val extra = StringBuilder()
        val moon = Astro.moon(store.lat, store.lon, now)
        if (moon.pos.alt > 0) extra.append(String.format(Locale.GERMANY, " · Mond %.0f°, %d %% beleuchtet", moon.pos.alt, (moon.illum * 100).toInt()))
        val vis = Astro.planets(store.lat, store.lon, now).filter { it.pos.alt > 3 }.joinToString(", ") { it.name }
        if (vis.isNotEmpty() && elev < -4) extra.append(" · $vis")
        val s = iss
        if (s != null && s.sunlit && elev < -4 &&
            Astro.satellitePos(store.lat, store.lon, s.lat, s.lon, s.altKm).alt > 8) extra.append(" · ISS sichtbar!")
        setStatus("$loc · $wtxt · $sun$extra" + if (failed) " (offline)" else "")
    }

    private fun setStatus(s: String) { txtStatus.text = s }

    /**
     * Eingebautes Bergbild mit fertig markiertem Himmel und abgestimmten Einstellungen.
     * Wird einmalig beim ersten Start dieser Version geladen.
     */
    private fun applyPresetIfNeeded() {
        val presetVersion = 1
        if (store.presetVersion >= presetVersion) return
        try {
            val bmp = BitmapFactory.decodeResource(resources, R.drawable.preset_wallpaper,
                BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    inScaled = false
                }) ?: return
            store.saveOriginal(bmp)
            bmp.recycle()
            // Horizontlinie über den fernsten Bergketten (aus dem Bild ausgemessen), dann über die oberen Ecken
            store.polygon = listOf(
                android.graphics.PointF(0f, 0.1096f),
                android.graphics.PointF(0.0823f, 0.1115f),
                android.graphics.PointF(0.1657f, 0.1116f),
                android.graphics.PointF(0.2491f, 0.1100f),
                android.graphics.PointF(0.3325f, 0.1062f),
                android.graphics.PointF(0.4160f, 0.1092f),
                android.graphics.PointF(0.4994f, 0.1117f),
                android.graphics.PointF(0.5828f, 0.1180f),
                android.graphics.PointF(0.6663f, 0.1124f),
                android.graphics.PointF(0.7497f, 0.1136f),
                android.graphics.PointF(0.8331f, 0.1099f),
                android.graphics.PointF(0.9166f, 0.1105f),
                android.graphics.PointF(1f, 0.1102f),
                android.graphics.PointF(1f, 0f),
                android.graphics.PointF(0f, 0f)
            )
            store.softness = 15     // kurzer weicher Übergang, Original-Abendrot scheint nicht durch
            store.structure = 30    // leichter Fotolook
            store.haze = 18         // Himmelsfarbe färbt die fernen Bergketten
            store.viewAz = 250      // Blick nach Westsüdwest -> Sonnenuntergang im Bild
            store.hfov = 60
            store.alsoLock = true
            store.presetVersion = presetVersion
        } catch (e: Exception) {
            // Preset ist nur ein Komfort – bei Fehler normal weiter
        }
    }

    private fun dirLabel(az: Int): String {
        val names = arrayOf("N", "NO", "O", "SO", "S", "SW", "W", "NW")
        return "Richtung ${az}° ${names[((az + 22) % 360) / 45]}"
    }

    // ---------------- Bild laden ----------------

    private fun loadCurrentWallpaper() {
        // Android verlangt zum Auslesen des Hintergrunds Speicherzugriff
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!Environment.isExternalStorageManager()) {
                AlertDialog.Builder(this)
                    .setTitle("Zugriff nötig")
                    .setMessage("Ab Android 13 darf eine App das aktuelle Hintergrundbild nur mit \"Zugriff auf alle Dateien\" lesen. " +
                        "Bitte erlaube das im nächsten Fenster und tippe dann nochmal auf \"Hintergrund laden\".\n\n" +
                        "Alternativ: \"Bild wählen\" und dein Hintergrundbild aus der Galerie nehmen.")
                    .setPositiveButton("Erlauben") { _, _ ->
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:$packageName")))
                        } catch (e: Exception) {
                            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        }
                    }
                    .setNegativeButton("Bild wählen") { _, _ -> pickImage() }
                    .show()
                return
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }

        if (original != null) {
            AlertDialog.Builder(this)
                .setMessage("Wichtig: Wenn die App schon einen Himmel gesetzt hat, ist das aktuelle Hintergrundbild bereits verändert. " +
                    "Trotzdem neu laden?")
                .setPositiveButton("Laden") { _, _ -> readWallpaper() }
                .setNegativeButton("Abbrechen", null)
                .show()
        } else {
            readWallpaper()
        }
    }

    @SuppressLint("MissingPermission")
    private fun readWallpaper() {
        try {
            val wm = WallpaperManager.getInstance(this)
            val d: Drawable? = wm.drawable
            if (d == null) {
                toast("Kein Bild gefunden (Live-Hintergrund?) – nimm \"Bild wählen\"")
                return
            }
            setOriginal(drawableToBitmap(d))
        } catch (e: SecurityException) {
            toast("Kein Zugriff aufs Hintergrundbild – nimm \"Bild wählen\"")
        } catch (e: Exception) {
            toast("Fehler: ${e.message}")
        }
    }

    private fun drawableToBitmap(d: Drawable): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null) return d.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val dm = resources.displayMetrics
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else dm.widthPixels
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else dm.heightPixels
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(b))
        return b
    }

    @Suppress("DEPRECATION")
    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            thread {
                val bmp = try {
                    contentResolver.openInputStream(uri)?.use { s ->
                        BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply {
                            inPreferredConfig = Bitmap.Config.ARGB_8888
                        })
                    }
                } catch (e: Exception) { null }
                runOnUiThread {
                    if (bmp == null) toast("Bild konnte nicht geladen werden") else setOriginal(bmp)
                }
            }
        }
    }

    private fun setOriginal(src: Bitmap) {
        val bmp = scaleDown(src)
        original = bmp
        editor.image = bmp
        if (previewOn) togglePreview()
        thread { store.saveOriginal(bmp) }
        toast("Bild geladen – jetzt den Himmel markieren")
    }

    private fun scaleDown(b: Bitmap): Bitmap {
        val m = max(b.width, b.height)
        if (m <= MAX_SIDE) return b
        val s = MAX_SIDE / m.toFloat()
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    // ---------------- Vorschau ----------------

    private fun togglePreview() {
        if (original == null) { toast("Erst ein Bild laden"); return }
        previewOn = !previewOn
        previewBar.visibility = if (previewOn) View.VISIBLE else View.GONE
        btnPreview.text = if (previewOn) "Bearbeiten" else "Vorschau"
        if (previewOn) {
            seekTime.progress = 0
            renderPreview()
        } else {
            editor.preview = null
        }
    }

    /** Regler: 0 = jetzt, jeder Schritt = +15 min (bis +24 h) – zum Ausprobieren. */
    private fun renderPreview() {
        if (!previewOn) return
        val orig = original ?: return
        val time = System.currentTimeMillis() + seekTime.progress * 15L * 60_000L
        txtTime.text = if (seekTime.progress == 0) "jetzt"
                       else SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(time))
        val job = ++previewJob
        val poly = editor.points.toList()
        // ISS-Position gilt nur für "jetzt"
        val scene = Updater.buildScene(store, weather, time, if (seekTime.progress == 0) iss else null)
        val soft = store.softness
        val struct = store.structure
        val hz = store.haze
        val keep = store.keepColors
        thread {
            // Für flüssige Vorschau kleiner rechnen
            val s = 1080f / max(orig.width, orig.height)
            val small = if (s < 1f) Bitmap.createScaledBitmap(orig, (orig.width * s).toInt(), (orig.height * s).toInt(), true) else orig
            val out = SkyRenderer.render(small, poly, scene, soft, struct, hz, keep)
            if (small !== orig) small.recycle()
            runOnUiThread {
                if (job == previewJob && previewOn) editor.preview = out
            }
        }
    }

    // ---------------- Anwenden ----------------

    /** Animierten Live-Hintergrund auswählen (Android zeigt dann eine Vorschau mit "Festlegen"). */
    private fun startLive() {
        if (original == null) { toast("Erst ein Bild laden"); return }
        if (editor.points.size < 3) { toast("Markiere den Himmel mit mindestens 3 Punkten"); return }
        store.polygon = editor.points.toList()
        if (Updater.isLiveActive(this)) {
            store.requestRefresh()
            toast("Live-Hintergrund aktualisiert ✓")
            return
        }
        try {
            startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                android.content.ComponentName(this, LiveSkyService::class.java)
            ))
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                toast("\"Himmel Live\" in der Liste auswählen")
            } catch (e2: Exception) {
                toast("Live-Hintergründe werden auf diesem Handy nicht unterstützt")
            }
        }
    }

    private fun applyNow() {
        val orig = original ?: run { toast("Erst ein Bild laden"); return }
        if (editor.points.size < 3) { toast("Markiere den Himmel mit mindestens 3 Punkten"); return }
        store.polygon = editor.points.toList()
        if (Updater.isLiveActive(this)) {
            // Live-Hintergrund läuft: nicht durch ein Standbild ersetzen, nur neu berechnen lassen
            store.requestRefresh()
            toast("Live-Hintergrund aktualisiert ✓")
            return
        }
        setStatus("Wird angewendet …")
        val scene = Updater.buildScene(store, weather, System.currentTimeMillis(), iss)
        val lock = store.alsoLock
        thread {
            val msg = try {
                val out = SkyRenderer.render(orig, store.polygon, scene, store.softness, store.structure, store.haze, store.keepColors)
                Updater.applyWallpaper(this, out, lock)
                out.recycle()
                "Hintergrund gesetzt ✓"
            } catch (e: Exception) {
                "Fehler: ${e.message}"
            }
            runOnUiThread { toast(msg); updateStatus() }
        }
    }

    // ---------------- Berechtigungen ----------------

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED }
        when (requestCode) {
            REQ_LOCATION -> if (ok) requestLocation() else {
                setStatus("Ohne Standort wird Wien verwendet")
                fetchWeather()
            }
            REQ_STORAGE -> if (ok) readWallpaper() else toast("Ohne Zugriff bitte \"Bild wählen\" verwenden")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
