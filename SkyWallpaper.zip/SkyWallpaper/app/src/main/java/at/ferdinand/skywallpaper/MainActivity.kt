package at.ferdinand.skywallpaper

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var editor: SkyEditorView
    private lateinit var txtStatus: TextView
    private lateinit var txtTime: TextView
    private lateinit var seekTime: SeekBar
    private lateinit var previewBar: View
    private lateinit var btnPreview: Button

    private var original: Bitmap? = null
    private var weather: Weather? = null
    private var previewOn = false
    private var previewJob = 0

    companion object {
        private const val REQ_LOCATION = 1
        private const val REQ_STORAGE = 2
        private const val REQ_PICK = 3
        private const val MAX_SIDE = 2880
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        editor = findViewById(R.id.editor)
        txtStatus = findViewById(R.id.txtStatus)
        txtTime = findViewById(R.id.txtTime)
        seekTime = findViewById(R.id.seekTime)
        previewBar = findViewById(R.id.previewBar)
        btnPreview = findViewById(R.id.btnPreview)

        weather = store.cachedWeather
        editor.setPoints(store.polygon)
        editor.onChanged = { store.polygon = editor.points.toList() }

        thread {
            val bmp = store.loadOriginal()
            runOnUiThread {
                if (bmp != null) {
                    original = bmp
                    editor.image = bmp
                }
            }
        }

        findViewById<Button>(R.id.btnWallpaper).setOnClickListener { loadCurrentWallpaper() }
        findViewById<Button>(R.id.btnPick).setOnClickListener { pickImage() }
        findViewById<Button>(R.id.btnUndo).setOnClickListener { editor.undo() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Alle Punkte löschen?")
                .setPositiveButton("Löschen") { _, _ -> editor.clear() }
                .setNegativeButton("Abbrechen", null)
                .show()
        }
        findViewById<Button>(R.id.btnTop).setOnClickListener { editor.closeOverTop() }
        btnPreview.setOnClickListener { togglePreview() }
        findViewById<Button>(R.id.btnApply).setOnClickListener { applyNow() }

        seekTime.progress = 0
        seekTime.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { renderPreview() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        val swAuto = findViewById<Switch>(R.id.swAuto)
        swAuto.isChecked = store.autoUpdate
        swAuto.setOnCheckedChangeListener { _, on ->
            store.autoUpdate = on
            Updater.schedule(this, on)
            toast(if (on) "Automatische Aktualisierung an" else "Automatische Aktualisierung aus")
        }
        val cbLock = findViewById<CheckBox>(R.id.cbLock)
        cbLock.isChecked = store.alsoLock
        cbLock.setOnCheckedChangeListener { _, on -> store.alsoLock = on; store.lastKey = null }

        if (store.autoUpdate) Updater.schedule(this, true)
        requestLocation()
    }

    // ---------------- Standort & Wetter ----------------

    private fun requestLocation() {
        val granted = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                REQ_LOCATION
            )
            return
        }
        val last = Updater.lastKnownLocation(this)
        if (last != null) {
            store.saveLocation(last.first, last.second)
            fetchWeather()
        } else {
            setStatus("Standort wird ermittelt …")
        }
        requestFreshLocation()
    }

    @SuppressLint("MissingPermission")
    private fun requestFreshLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            if (!store.hasLocation) setStatus("Standort ist aus – bitte in den Einstellungen einschalten")
            fetchWeather()
            return
        }
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(loc: Location) {
                    lm.removeUpdates(this)
                    store.saveLocation(loc.latitude, loc.longitude)
                    fetchWeather()
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: SecurityException) {
            fetchWeather()
        }
    }

    private fun fetchWeather() {
        val lat = store.lat
        val lon = store.lon
        thread {
            val w = try { Weather.fetch(lat, lon) } catch (e: Exception) { null }
            runOnUiThread {
                if (w != null) {
                    weather = w
                    store.cachedWeather = w
                }
                updateStatus(w == null)
                if (previewOn) renderPreview()
            }
        }
    }

    private fun updateStatus(failed: Boolean = false) {
        val w = weather
        val elev = SunCalc.elevation(store.lat, store.lon, System.currentTimeMillis())
        val loc = if (store.hasLocation) String.format(Locale.GERMANY, "%.2f°, %.2f°", store.lat, store.lon)
                  else "Wien (Standard)"
        val wtxt = if (w != null) String.format(Locale.GERMANY, "%s · %.0f °C · %d %% Wolken", w.description(), w.temperature, w.cloudCover)
                   else "kein Wetter"
        val sun = String.format(Locale.GERMANY, "Sonne %.0f°", elev)
        setStatus("$loc · $wtxt · $sun" + if (failed) " (offline)" else "")
    }

    private fun setStatus(s: String) { txtStatus.text = s }

    // ---------------- Bild laden ----------------

    private fun loadCurrentWallpaper() {
        // Android verlangt zum Auslesen des Hintergrunds Speicherzugriff
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!Environment.isExternalStorageManager()) {
                AlertDialog.Builder(this)
                    .setTitle("Zugriff nötig")
                    .setMessage("Ab Android 13 darf eine App das aktuelle Hintergrundbild nur mit \"Zugriff auf alle Dateien\" lesen. " +
                        "Bitte erlaube das im nächsten Fenster und tippe dann nochmal auf \"Hintergrund laden\".\n\n" +
                        "Alternativ: \"Bild wählen\" und dein Hintergrundbild aus der Galerie nehmen.")
                    .setPositiveButton("Erlauben") { _, _ ->
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:$packageName")))
                        } catch (e: Exception) {
                            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        }
                    }
                    .setNegativeButton("Bild wählen") { _, _ -> pickImage() }
                    .show()
                return
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }

        if (original != null) {
            AlertDialog.Builder(this)
                .setMessage("Wichtig: Wenn die App schon einen Himmel gesetzt hat, ist das aktuelle Hintergrundbild bereits verändert. " +
                    "Trotzdem neu laden?")
                .setPositiveButton("Laden") { _, _ -> readWallpaper() }
                .setNegativeButton("Abbrechen", null)
                .show()
        } else {
            readWallpaper()
        }
    }

    @SuppressLint("MissingPermission")
    private fun readWallpaper() {
        try {
            val wm = WallpaperManager.getInstance(this)
            val d: Drawable? = wm.drawable
            if (d == null) {
                toast("Kein Bild gefunden (Live-Hintergrund?) – nimm \"Bild wählen\"")
                return
            }
            setOriginal(drawableToBitmap(d))
        } catch (e: SecurityException) {
            toast("Kein Zugriff aufs Hintergrundbild – nimm \"Bild wählen\"")
        } catch (e: Exception) {
            toast("Fehler: ${e.message}")
        }
    }

    private fun drawableToBitmap(d: Drawable): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null) return d.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val dm = resources.displayMetrics
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else dm.widthPixels
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else dm.heightPixels
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(b))
        return b
    }

    @Suppress("DEPRECATION")
    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            thread {
                val bmp = try {
                    contentResolver.openInputStream(uri)?.use { s ->
                        BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply {
                            inPreferredConfig = Bitmap.Config.ARGB_8888
                        })
                    }
                } catch (e: Exception) { null }
                runOnUiThread {
                    if (bmp == null) toast("Bild konnte nicht geladen werden") else setOriginal(bmp)
                }
            }
        }
    }

    private fun setOriginal(src: Bitmap) {
        val bmp = scaleDown(src)
        original = bmp
        editor.image = bmp
        if (previewOn) togglePreview()
        thread { store.saveOriginal(bmp) }
        toast("Bild geladen – jetzt den Himmel markieren")
    }

    private fun scaleDown(b: Bitmap): Bitmap {
        val m = max(b.width, b.height)
        if (m <= MAX_SIDE) return b
        val s = MAX_SIDE / m.toFloat()
        return Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    // ---------------- Vorschau ----------------

    private fun togglePreview() {
        if (original == null) { toast("Erst ein Bild laden"); return }
        previewOn = !previewOn
        previewBar.visibility = if (previewOn) View.VISIBLE else View.GONE
        btnPreview.text = if (previewOn) "Bearbeiten" else "Vorschau"
        if (previewOn) {
            seekTime.progress = 0
            renderPreview()
        } else {
            editor.preview = null
        }
    }

    /** Regler: 0 = jetzt, jeder Schritt = +15 min (bis +24 h) – zum Ausprobieren. */
    private fun renderPreview() {
        if (!previewOn) return
        val orig = original ?: return
        val time = System.currentTimeMillis() + seekTime.progress * 15L * 60_000L
        txtTime.text = if (seekTime.progress == 0) "jetzt"
                       else SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(time))
        val job = ++previewJob
        val poly = editor.points.toList()
        val scene = Updater.buildScene(store, weather, time)
        thread {
            // Für flüssige Vorschau kleiner rechnen
            val s = 1080f / max(orig.width, orig.height)
            val small = if (s < 1f) Bitmap.createScaledBitmap(orig, (orig.width * s).toInt(), (orig.height * s).toInt(), true) else orig
            val out = SkyRenderer.render(small, poly, scene)
            if (small !== orig) small.recycle()
            runOnUiThread {
                if (job == previewJob && previewOn) editor.preview = out
            }
        }
    }

    // ---------------- Anwenden ----------------

    private fun applyNow() {
        val orig = original ?: run { toast("Erst ein Bild laden"); return }
        if (editor.points.size < 3) { toast("Markiere den Himmel mit mindestens 3 Punkten"); return }
        store.polygon = editor.points.toList()
        setStatus("Wird angewendet …")
        val scene = Updater.buildScene(store, weather)
        val lock = store.alsoLock
        thread {
            val msg = try {
                val out = SkyRenderer.render(orig, store.polygon, scene)
                Updater.applyWallpaper(this, out, lock)
                out.recycle()
                "Hintergrund gesetzt ✓"
            } catch (e: Exception) {
                "Fehler: ${e.message}"
            }
            runOnUiThread { toast(msg); updateStatus() }
        }
    }

    // ---------------- Berechtigungen ----------------

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED }
        when (requestCode) {
            REQ_LOCATION -> if (ok) requestLocation() else {
                setStatus("Ohne Standort wird Wien verwendet")
                fetchWeather()
            }
            REQ_STORAGE -> if (ok) readWallpaper() else toast("Ohne Zugriff bitte \"Bild wählen\" verwenden")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
