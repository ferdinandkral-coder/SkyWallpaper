package at.ferdinand.skywallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import java.io.File
import java.io.FileOutputStream

/** Speichert Originalbild, Himmels-Polygon, Standort und Einstellungen. */
class Store(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("sky", Context.MODE_PRIVATE)
    private val originalFile = File(ctx.filesDir, "original.png")

    // ---------- Originalbild ----------
    fun saveOriginal(bmp: Bitmap) {
        FileOutputStream(originalFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        prefs.edit().remove("lastKey").apply()
    }

    fun loadOriginal(): Bitmap? {
        if (!originalFile.exists()) return null
        val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return BitmapFactory.decodeFile(originalFile.absolutePath, opts)
    }

    // ---------- Polygon (normierte Koordinaten 0..1) ----------
    var polygon: List<PointF>
        get() {
            val s = prefs.getString("poly", "") ?: ""
            if (s.isBlank()) return emptyList()
            return s.split(";").mapNotNull { p ->
                val xy = p.split(",")
                if (xy.size == 2) PointF(xy[0].toFloat(), xy[1].toFloat()) else null
            }
        }
        set(value) {
            prefs.edit()
                .putString("poly", value.joinToString(";") { "${it.x},${it.y}" })
                .remove("lastKey")
                .apply()
        }

    // ---------- Standort ----------
    fun saveLocation(lat: Double, lon: Double) {
        prefs.edit()
            .putFloat("lat", lat.toFloat())
            .putFloat("lon", lon.toFloat())
            .putBoolean("hasLoc", true)
            .apply()
    }

    val hasLocation: Boolean get() = prefs.getBoolean("hasLoc", false)
    val lat: Double get() = prefs.getFloat("lat", 48.21f).toDouble()
    val lon: Double get() = prefs.getFloat("lon", 16.37f).toDouble()

    // ---------- Wetter-Cache ----------
    var cachedWeather: Weather?
        get() = Weather.fromString(prefs.getString("weather", null))
        set(value) {
            prefs.edit().putString("weather", value?.toStorageString()).apply()
        }

    // ---------- Einstellungen ----------
    var autoUpdate: Boolean
        get() = prefs.getBoolean("auto", false)
        set(v) = prefs.edit().putBoolean("auto", v).apply()

    var alsoLock: Boolean
        get() = prefs.getBoolean("lock", true)
        set(v) = prefs.edit().putBoolean("lock", v).apply()

    /** Weicher Übergang am unteren Himmelsrand, 0..100 (% der Himmelshöhe). */
    var softness: Int
        get() = prefs.getInt("soft", 35)
        set(v) = prefs.edit().putInt("soft", v).remove("lastKey").apply()

    /** Dunst: wie weit (in % der Bildhöhe) die Himmelsfarbe in die Berge unter dem Horizont zieht. */
    var haze: Int
        get() = prefs.getInt("haze", 0)
        set(v) = prefs.edit().putInt("haze", v).remove("lastKey").apply()

    /** Originalfarben 0..100: wie viel vom Foto durch Himmel/Wolken/Tönung durchscheint. */
    var keepColors: Int
        get() = prefs.getInt("keep", 60)
        set(v) = prefs.edit().putInt("keep", v).remove("lastKey").apply()

    /** Version des eingebauten Bild-Presets, das schon geladen wurde. */
    var presetVersion: Int
        get() = prefs.getInt("preset", 0)
        set(v) = prefs.edit().putInt("preset", v).apply()

    /** Himmelsrichtung, in die das Bild schaut (0 = Nord, 90 = Ost, 180 = Süd, 270 = West). */
    var viewAz: Int
        get() = prefs.getInt("viewAz", 180)
        set(v) = prefs.edit().putInt("viewAz", ((v % 360) + 360) % 360).remove("lastKey").apply()

    /** Sichtfeld: wie viel Grad die Bildbreite zeigt. */
    var hfov: Int
        get() = prefs.getInt("hfov", 60)
        set(v) = prefs.edit().putInt("hfov", v.coerceIn(20, 180)).remove("lastKey").apply()

    /** Wie stark die Hell/Dunkel-Details des Originalfotos im neuen Himmel bleiben, 0..100. */
    var structure: Int
        get() = prefs.getInt("struct", 50)
        set(v) = prefs.edit().putInt("struct", v).remove("lastKey").apply()

    /** Schlüssel des zuletzt gesetzten Zustands, um unnötiges Neusetzen zu vermeiden. */
    var lastKey: String?
        get() = prefs.getString("lastKey", null)
        set(v) = prefs.edit().putString("lastKey", v).apply()
}
