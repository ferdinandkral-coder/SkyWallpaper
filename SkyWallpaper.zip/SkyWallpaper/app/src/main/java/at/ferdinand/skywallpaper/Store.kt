package at.ferdinand.skywallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import java.io.File
import java.io.FileOutputStream

/** Speichert Originalbild, Himmels-Polygon, Standort und Einstellungen. */
class Store(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("sky", Context.MODE_PRIVATE)
    private val originalFile = File(ctx.filesDir, "original.png")

    // ---------- Originalbild ----------
    fun saveOriginal(bmp: Bitmap) {
        FileOutputStream(originalFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        prefs.edit().remove("lastKey").apply()
    }

    fun loadOriginal(): Bitmap? {
        if (!originalFile.exists()) return null
        val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return BitmapFactory.decodeFile(originalFile.absolutePath, opts)
    }

    // ---------- Polygon (normierte Koordinaten 0..1) ----------
    var polygon: List<PointF>
        get() {
            val s = prefs.getString("poly", "") ?: ""
            if (s.isBlank()) return emptyList()
            return s.split(";").mapNotNull { p ->
                val xy = p.split(",")
                if (xy.size == 2) PointF(xy[0].toFloat(), xy[1].toFloat()) else null
            }
        }
        set(value) {
            prefs.edit()
                .putString("poly", value.joinToString(";") { "${it.x},${it.y}" })
                .remove("lastKey")
                .apply()
        }

    // ---------- Standort ----------
    fun saveLocation(lat: Double, lon: Double) {
        prefs.edit()
            .putFloat("lat", lat.toFloat())
            .putFloat("lon", lon.toFloat())
            .putBoolean("hasLoc", true)
            .apply()
    }

    val hasLocation: Boolean get() = prefs.getBoolean("hasLoc", false)
    val lat: Double get() = prefs.getFloat("lat", 48.21f).toDouble()
    val lon: Double get() = prefs.getFloat("lon", 16.37f).toDouble()

    // ---------- Wetter-Cache ----------
    var cachedWeather: Weather?
        get() = Weather.fromString(prefs.getString("weather", null))
        set(value) {
            prefs.edit().putString("weather", value?.toStorageString()).apply()
        }

    // ---------- Einstellungen ----------
    var autoUpdate: Boolean
        get() = prefs.getBoolean("auto", false)
        set(v) = prefs.edit().putBoolean("auto", v).apply()

    var alsoLock: Boolean
        get() = prefs.getBoolean("lock", true)
        set(v) = prefs.edit().putBoolean("lock", v).apply()

    /** Schlüssel des zuletzt gesetzten Zustands, um unnötiges Neusetzen zu vermeiden. */
    var lastKey: String?
        get() = prefs.getString("lastKey", null)
        set(v) = prefs.edit().putString("lastKey", v).apply()
}
