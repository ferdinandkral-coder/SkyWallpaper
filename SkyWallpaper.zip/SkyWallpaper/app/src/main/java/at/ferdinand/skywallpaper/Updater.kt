package at.ferdinand.skywallpaper

import android.Manifest
import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Gemeinsame Logik: Wetter holen, Bild rendern, als Hintergrund setzen. */
object Updater {
    private const val PERIODIC = "sky_periodic"
    private const val ONCE = "sky_once"

    /** Letzten bekannten Standort holen (ohne auf GPS zu warten). */
    @SuppressLint("MissingPermission")
    fun lastKnownLocation(ctx: Context): Pair<Double, Double>? {
        val fine = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return try {
            lm.getProviders(true)
                .mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
                ?.let { Pair(it.latitude, it.longitude) }
        } catch (e: SecurityException) {
            null
        }
    }

    fun buildScene(store: Store, weather: Weather?, time: Long = System.currentTimeMillis()) =
        SkyRenderer.Scene(
            elevation = SunCalc.elevation(store.lat, store.lon, time),
            sunRising = SunCalc.isRising(store.lat, store.lon, time),
            weather = weather,
            timeMillis = time
        )

    /**
     * Führt ein komplettes Update aus. Blockierend.
     * @param force true = auch setzen, wenn sich nichts geändert hat
     * @return Statustext
     */
    fun runUpdate(ctx: Context, force: Boolean): String {
        val store = Store(ctx)
        val original = store.loadOriginal() ?: return "Kein Hintergrundbild gespeichert"

        lastKnownLocation(ctx)?.let { store.saveLocation(it.first, it.second) }

        val weather = try {
            Weather.fetch(store.lat, store.lon).also { store.cachedWeather = it }
        } catch (e: Exception) {
            store.cachedWeather
        }

        val now = System.currentTimeMillis()
        val scene = buildScene(store, weather, now)

        // Nur neu setzen, wenn sich sichtbar etwas geändert hat
        val key = listOf(
            Math.round(scene.elevation / 1.5),
            weather?.code ?: -1,
            (weather?.cloudCover ?: 0) / 10,
            now / 3_600_000 // spätestens jede Stunde (Wolken ziehen weiter)
        ).joinToString("_")
        if (!force && key == store.lastKey) {
            original.recycle()
            return "Keine Änderung"
        }

        val result = SkyRenderer.render(original, store.polygon, scene)
        original.recycle()
        applyWallpaper(ctx, result, store.alsoLock)
        result.recycle()
        store.lastKey = key
        return "Hintergrund aktualisiert"
    }

    fun applyWallpaper(ctx: Context, bmp: android.graphics.Bitmap, alsoLock: Boolean) {
        val wm = WallpaperManager.getInstance(ctx)
        val flags = if (alsoLock) WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                    else WallpaperManager.FLAG_SYSTEM
        wm.setBitmap(bmp, null, true, flags)
    }

    fun schedule(ctx: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (!enabled) {
            wm.cancelUniqueWork(PERIODIC)
            return
        }
        val req = PeriodicWorkRequestBuilder<SkyWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
            .build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun runOnceInBackground(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SkyWorker>().build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(ONCE, ExistingWorkPolicy.REPLACE, req)
    }
}

class SkyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            Updater.runUpdate(applicationContext, force = false)
            Result.success()
        } catch (e: Throwable) {
            Result.retry()
        }
    }
}
