package at.ferdinand.skywallpaper

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Malt einen neuen Himmel (passend zu Sonnenstand und Wetter) in den ausgewählten
 * Polygon-Bereich und färbt den Rest des Bildes passend zur Tageszeit ein.
 */
object SkyRenderer {

    data class Scene(
        val elevation: Double,     // Sonnenhöhe in Grad
        val sunRising: Boolean,    // Vormittag?
        val weather: Weather?,
        val timeMillis: Long
    )

    // Stützstellen: Sonnenhöhe -> Himmel oben, Himmel unten, Farbfaktor für die Landschaft
    private class Key(val elev: Double, val top: Int, val bottom: Int, val r: Float, val g: Float, val b: Float)

    private val keys = listOf(
        Key(-90.0, 0x02040B, 0x060B1A, 0.26f, 0.30f, 0.42f),
        Key(-18.0, 0x02040B, 0x070D1E, 0.28f, 0.32f, 0.45f),
        Key(-12.0, 0x050A1C, 0x111D40, 0.32f, 0.36f, 0.50f),
        Key(-6.0, 0x0F1C45, 0x3D4275, 0.45f, 0.45f, 0.60f),
        Key(-2.0, 0x22356C, 0xD8755C, 0.66f, 0.58f, 0.62f),
        Key(2.0, 0x3461A8, 0xF6A86C, 0.92f, 0.80f, 0.72f),
        Key(8.0, 0x3A78C9, 0xC2DAEF, 1.00f, 0.95f, 0.90f),
        Key(20.0, 0x2C6ED6, 0x9DCBF6, 1.00f, 1.00f, 1.00f),
        Key(90.0, 0x1E62D6, 0x8CC2F7, 1.03f, 1.03f, 1.03f)
    )

    fun render(original: Bitmap, polygon: List<PointF>, scene: Scene): Bitmap {
        val w = original.width
        val h = original.height
        val e = scene.elevation
        val wx = scene.weather

        // ---- Grundfarben nach Sonnenstand ----
        val i = keys.indexOfLast { it.elev <= e }.coerceIn(0, keys.size - 2)
        val k0 = keys[i]
        val k1 = keys[i + 1]
        val t = ((e - k0.elev) / (k1.elev - k0.elev)).toFloat().coerceIn(0f, 1f)
        var top = lerpColor(k0.top, k1.top, t)
        var bottom = lerpColor(k0.bottom, k1.bottom, t)
        var gr = lerp(k0.r, k1.r, t)
        var gg = lerp(k0.g, k1.g, t)
        var gb = lerp(k0.b, k1.b, t)

        // ---- Wetter: Bewölkung macht den Himmel grau ----
        val cover = (wx?.cloudCover ?: 0) / 100f
        val wet = wx != null && (wx.isRain || wx.isDrizzle || wx.isSnow || wx.isThunder)
        var gray = (cover * 0.85f + if (wet) 0.2f else 0f).coerceIn(0f, 1f)
        if (wx?.isFog == true) gray = 1f
        val darkness = when {
            wx?.isThunder == true -> 0.55f
            wx?.isRain == true -> 0.72f
            wx?.isSnow == true -> 0.92f
            wx?.isDrizzle == true -> 0.8f
            else -> 0.9f
        }
        if (gray > 0f) {
            top = lerpColor(top, grayOf(top, darkness * 1.1f), gray)
            bottom = lerpColor(bottom, grayOf(bottom, darkness), gray)
            val dim = 1f - 0.22f * gray * (1.6f - darkness)
            gr *= dim; gg *= dim; gb *= dim
            // Graue Tage: Landschaft entsättigt leicht in Richtung Blau
            gb = lerp(gb, (gr + gg + gb) / 3f, 0.3f * gray)
        }

        val night = ramp(e, -3.0, -14.0)       // 0 = Tag, 1 = tiefe Nacht
        val golden = 1f - ramp(kotlin.math.abs(e - 1.0), 0.0, 9.0) // um Sonnenauf-/untergang

        // ---- 1) Landschaft einfärben ----
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val cm = ColorMatrix(
            floatArrayOf(
                gr, 0f, 0f, 0f, 0f,
                0f, gg, 0f, 0f, 0f,
                0f, 0f, gb, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        // Nachts etwas Sättigung rausnehmen (Augen sehen nachts weniger Farbe)
        val sat = ColorMatrix().apply { setSaturation(1f - 0.45f * night) }
        cm.postConcat(sat)
        canvas.drawBitmap(original, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        })

        // ---- 2) Himmel malen ----
        if (polygon.size >= 3) {
            val path = Path()
            polygon.forEachIndexed { idx, p ->
                val x = p.x * w
                val y = p.y * h
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            val bounds = RectF()
            path.computeBounds(bounds, true)
            if (bounds.height() < 2f) bounds.bottom = bounds.top + 2f

            val sky = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val sc = Canvas(sky)

            // Verlauf
            val grad = Paint().apply {
                shader = LinearGradient(
                    0f, bounds.top, 0f, bounds.bottom,
                    intArrayOf(top, lerpColor(top, bottom, 0.55f), bottom),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            }
            sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), grad)

            val clearness = (1f - cover).pow(1.5f) * if (wet || wx?.isFog == true) 0.2f else 1f

            // Sterne
            if (night > 0f && clearness > 0.02f) drawStars(sc, bounds, night * clearness, scene.timeMillis)

            // Mond
            if (night > 0.2f && clearness > 0.1f) drawMoon(sc, bounds, night * clearness, scene.timeMillis)

            // Sonne (nur bei niedriger/mittlerer Höhe und nicht zu bewölkt)
            if (e > -2 && e < 35 && cover < 0.75f && !wet) {
                drawSun(sc, bounds, e, scene.sunRising, (1f - cover / 0.75f).coerceIn(0f, 1f), golden)
            }

            // Wolken
            if (cover > 0.05f || wx?.isFog == true) {
                drawClouds(sc, bounds, cover, e, night, golden, darkness, wx, scene.timeMillis)
            }

            // Nebel = milchiger Schleier
            if (wx?.isFog == true) {
                sc.drawColor(Color.argb(150, 190, 196, 204).dimBy(1f - 0.75f * night))
            }

            // Maske mit weicher Kante
            val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val mc = Canvas(mask)
            val feather = max(2f, min(w, h) * 0.006f)
            mc.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                maskFilter = BlurMaskFilter(feather, BlurMaskFilter.Blur.NORMAL)
            })
            sc.drawBitmap(mask, 0f, 0f, Paint().apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            })
            canvas.drawBitmap(sky, 0f, 0f, null)
            sky.recycle()
            mask.recycle()
        }

        // ---- 3) Niederschlag übers ganze Bild ----
        if (wx != null) {
            if (wx.isRain || wx.isDrizzle || wx.isThunder) drawRain(canvas, w, h, wx, night, scene.timeMillis)
            if (wx.isSnow) drawSnow(canvas, w, h, wx, scene.timeMillis)
            if (wx.isFog) canvas.drawColor(Color.argb(55, 200, 205, 212).dimBy(1f - 0.75f * night))
        }
        return out
    }

    // ------------------------------------------------------------------

    private fun drawStars(c: Canvas, b: RectF, strength: Float, time: Long) {
        val rnd = Random(4242)
        val twinkle = Random(time / 900_000) // ändert sich alle 15 min leicht
        val count = ((b.width() * b.height()) / 2600f).toInt().coerceIn(40, 900)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = min(b.width(), b.height())
        for (n in 0 until count) {
            val x = b.left + rnd.nextFloat() * b.width()
            val y = b.top + rnd.nextFloat() * b.height()
            val mag = rnd.nextFloat().pow(3f)          // wenige helle, viele schwache
            val r = base * (0.0008f + 0.0022f * mag)
            // Sterne werden zum Horizont hin schwächer
            val heightFade = 1f - 0.6f * ((y - b.top) / b.height())
            val a = (strength * heightFade * (0.35f + 0.65f * mag) * (0.7f + 0.3f * twinkle.nextFloat()))
            val tint = when (rnd.nextInt(6)) { 0 -> 0xFFD9B0; 1 -> 0xB9CCFF; else -> 0xFFFFFF }
            p.color = (tint or 0xFF000000.toInt()).withAlpha((a * 255).toInt())
            c.drawCircle(x, y, max(0.7f, r), p)
        }
    }

    private fun drawMoon(c: Canvas, b: RectF, strength: Float, time: Long) {
        val synodic = 29.530588
        val refNewMoon = 947_182_440_000L // 06.01.2000 18:14 UTC
        val age = (((time - refNewMoon) / 86_400_000.0) % synodic + synodic) % synodic
        if (age < 1.5 || age > synodic - 1.5) return // Neumond

        val r = min(b.width(), b.height()) * 0.045f
        val cx = b.left + b.width() * 0.74f
        val cy = b.top + b.height() * 0.22f

        // Schein
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, r * 5f,
                Color.argb((70 * strength).toInt(), 200, 215, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        }
        c.drawCircle(cx, cy, r * 5f, glow)

        // Mondscheibe auf eigener Ebene, Schatten wird herausgeschnitten
        val size = (r * 2.4f).toInt().coerceAtLeast(4)
        val layer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        val lx = size / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(242, 238, 222) }
        lc.drawCircle(lx, lx, r, p)
        val half = synodic / 2
        val waxing = age < half
        val frac = if (waxing) age / half else (synodic - age) / half // 0 = neu, 1 = voll
        val offset = (2f * r * frac.toFloat())
        val shadowX = if (waxing) lx - offset else lx + offset
        lc.drawCircle(shadowX, lx, r * 1.02f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        })
        c.drawBitmap(layer, cx - lx, cy - lx, Paint().apply { alpha = (255 * strength).toInt().coerceIn(0, 255) })
        layer.recycle()
    }

    private fun drawSun(c: Canvas, b: RectF, elev: Double, rising: Boolean, vis: Float, golden: Float) {
        val r = min(b.width(), b.height()) * 0.05f
        val cx = b.left + b.width() * (if (rising) 0.22f else 0.78f)
        val height = (elev / 35.0).toFloat().coerceIn(-0.05f, 1f)
        val cy = b.bottom - b.height() * (0.08f + 0.85f * height)

        val core = lerpColor(0xFFF6D8, 0xFFB25A, golden)
        val halo = lerpColor(0xFFF2C0, 0xFF8A4A, golden)

        val glowR = r * (6f + 6f * golden)
        c.drawCircle(cx, cy, glowR, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, glowR,
                intArrayOf(halo.withAlpha((170 * vis).toInt()), halo.withAlpha((40 * vis).toInt()), Color.TRANSPARENT),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        })
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx, cy, r,
                intArrayOf(core.withAlpha((255 * vis).toInt()), core.withAlpha((200 * vis).toInt())),
                null, Shader.TileMode.CLAMP)
        })
        // Warmes Leuchten am Horizont bei Sonnenauf-/untergang
        if (golden > 0.05f) {
            val bandTop = b.bottom - b.height() * 0.45f
            c.drawRect(b.left, bandTop, b.right, b.bottom, Paint().apply {
                shader = LinearGradient(0f, bandTop, 0f, b.bottom,
                    Color.TRANSPARENT, halo.withAlpha((90 * golden * vis).toInt()), Shader.TileMode.CLAMP)
            })
        }
    }

    private fun drawClouds(
        c: Canvas, b: RectF, cover: Float, elev: Double, night: Float, golden: Float,
        darkness: Float, wx: Weather?, time: Long
    ) {
        // Wolkenfarbe nach Licht
        var lit = 0xF2F4F8
        lit = lerpColor(lit, 0xFFB898, golden * 0.75f)
        lit = lerpColor(lit, 0x2A3146, night)
        lit = lerpColor(lit, grayOf(lit, darkness), (1f - darkness) * 2f)
        val shade = lerpColor(lit, 0x101420, 0.35f + 0.3f * night)

        val baseAlpha = if (night > 0.5f) 0.75f else 0.9f
        val rnd = Random(777)
        val clusters = (6 + cover * 34).toInt()
        val base = min(b.width(), b.height())
        // Wolken ziehen langsam mit dem Wind (Bild wird alle 15 min neu berechnet)
        val wind = ((wx?.windSpeed ?: 10.0).coerceIn(2.0, 60.0)).toFloat()
        val drift = ((time / 60_000L) % 100_000L) * wind * 0.00004f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        for (n in 0 until clusters) {
            val u = (rnd.nextFloat() + drift * (0.6f + 0.4f * rnd.nextFloat())) % 1f
            val cx = b.left - base * 0.2f + u * (b.width() + base * 0.4f)
            // eher im oberen/mittleren Bereich, Richtung Horizont flacher
            val v = rnd.nextFloat()
            val cy = b.top + b.height() * (0.05f + 0.85f * v)
            val perspective = 1f - 0.55f * v
            val size = base * (0.06f + 0.12f * rnd.nextFloat()) * (0.7f + 0.6f * cover) * perspective
            val puffs = 5 + rnd.nextInt(8)
            for (q in 0 until puffs) {
                val px = cx + (rnd.nextFloat() - 0.5f) * size * 2.8f
                val py = cy + (rnd.nextFloat() - 0.6f) * size * 0.7f
                val pr = size * (0.45f + 0.6f * rnd.nextFloat())
                val a = (baseAlpha * (0.45f + 0.55f * cover) * 255).toInt()
                // untere Seite etwas dunkler
                p.shader = RadialGradient(px, py - pr * 0.25f, pr,
                    intArrayOf(lit.withAlpha(a), lerpColor(lit, shade, 0.5f).withAlpha((a * 0.6f).toInt()), Color.TRANSPARENT),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(px, py, pr, p)
            }
        }
        // Bei starker Bewölkung geschlossene Wolkendecke
        if (cover > 0.6f) {
            val a = ((cover - 0.6f) / 0.4f * 200).toInt().coerceIn(0, 200)
            c.drawRect(b, Paint().apply {
                shader = LinearGradient(0f, b.top, 0f, b.bottom,
                    shade.withAlpha(a), lit.withAlpha((a * 0.7f).toInt()), Shader.TileMode.CLAMP)
            })
        }
    }

    private fun drawRain(c: Canvas, w: Int, h: Int, wx: Weather, night: Float, time: Long) {
        val rnd = Random(time / 900_000)
        val intensity = when {
            wx.isThunder -> 1f
            wx.isDrizzle -> 0.35f
            else -> (0.4f + wx.precipitation.toFloat() / 4f).coerceIn(0.4f, 1f)
        }
        val count = (w * h / 9000f * intensity).toInt().coerceAtMost(1400)
        val len = h * 0.035f
        val slant = (wx.windSpeed.toFloat() / 40f).coerceIn(0f, 0.6f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = max(1f, w / 900f)
            strokeCap = Paint.Cap.ROUND
        }
        val col = lerpColor(0xD8E2EE, 0x8090A8, night)
        for (n in 0 until count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val l = len * (0.5f + rnd.nextFloat())
            p.color = col.withAlpha((40 + rnd.nextInt(60)))
            c.drawLine(x, y, x - l * slant, y + l, p)
        }
    }

    private fun drawSnow(c: Canvas, w: Int, h: Int, wx: Weather, time: Long) {
        val rnd = Random(time / 900_000)
        val count = (w * h / 7000f).toInt().coerceAtMost(1500)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = min(w, h)
        for (n in 0 until count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val r = base * (0.0015f + 0.004f * rnd.nextFloat().pow(2f))
            p.color = Color.argb(120 + rnd.nextInt(120), 255, 255, 255)
            c.drawCircle(x, y, r, p)
        }
    }

    // ---------------- Hilfsfunktionen ----------------

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun ramp(v: Double, from: Double, to: Double): Float =
        ((v - from) / (to - from)).toFloat().coerceIn(0f, 1f)

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val r = ((a shr 16 and 0xFF) + ((b shr 16 and 0xFF) - (a shr 16 and 0xFF)) * tt).toInt()
        val g = ((a shr 8 and 0xFF) + ((b shr 8 and 0xFF) - (a shr 8 and 0xFF)) * tt).toInt()
        val bl = ((a and 0xFF) + ((b and 0xFF) - (a and 0xFF)) * tt).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Grau mit gleicher Helligkeit, leicht bläulich, mal Faktor. */
    private fun grayOf(c: Int, factor: Float): Int {
        val r = c shr 16 and 0xFF
        val g = c shr 8 and 0xFF
        val b = c and 0xFF
        val lum = (0.3f * r + 0.59f * g + 0.11f * b)
        val v = (lum * 0.55f + 150f * (lum / 255f).pow(0.4f) * 0.45f) * factor
        val gv = v.toInt().coerceIn(0, 255)
        return (0xFF shl 24) or ((gv * 0.96f).toInt() shl 16) or (gv shl 8) or (gv * 1.04f).toInt().coerceAtMost(255)
    }

    private fun Int.withAlpha(a: Int): Int = (this and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun Int.dimBy(f: Float): Int {
        val a = Color.alpha(this)
        val r = (Color.red(this) * f).toInt()
        val g = (Color.green(this) * f).toInt()
        val b = (Color.blue(this) * f).toInt()
        return Color.argb(a, r, g, b)
    }
}
