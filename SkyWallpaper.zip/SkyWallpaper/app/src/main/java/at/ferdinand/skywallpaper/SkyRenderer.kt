package at.ferdinand.skywallpaper

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Malt einen neuen Himmel (passend zu Sonnenstand und Wetter) in den ausgewählten
 * Polygon-Bereich und färbt den Rest des Bildes passend zur Tageszeit ein.
 */
object SkyRenderer {

    data class Scene(
        val elevation: Double,     // Sonnenhöhe in Grad
        val sunAz: Double,         // Sonnen-Azimut (0 = Nord, 90 = Ost)
        val weather: Weather?,
        val timeMillis: Long,
        val lat: Double,
        val lon: Double,
        val viewAz: Double,        // in welche Himmelsrichtung das Bild schaut
        val hfov: Double,          // Bildbreite in Grad
        val iss: Satellites.SatTrack? = null
    )

    /**
     * Für den Live-Hintergrund: Teile, die animiert werden, werden nicht ins Bild gemalt,
     * sondern hier abgelegt (Wolken als nahtlos wiederholbare Textur, Himmelsmaske, Niederschlag).
     */
    class LiveLayers {
        var cloudTile: Bitmap? = null      // nahtlos waagrecht wiederholbar
        var skyRect: RectF = RectF()        // Bereich, in den die Wolken gehören
        var mask: Bitmap? = null            // Himmelsform inkl. weichem Übergang (Alphakanal)
        var skyAlpha: Int = 255             // "Originalfarben" -> Wolken durchsichtiger
        var rain = false
        var snow = false
        var thunder = false
        var rainIntensity = 0f
        var windKmh = 10f
        var night = 0f
        var cloudAlpha: Int = 255           // Wolken bleiben auch bei "Originalfarben" deutlich

        // Eingabe: soll der Live-Hintergrund die Sterne selbst (als Zeitraffer) zeichnen?
        var wantLiveStars = false

        // Projektion & Sicht für Sterne/Flugzeuge im Live-Modus
        var viewAz = 180.0
        var ppd = 1f
        var ppdY = 1f
        var horizonY = 0f
        var starLimit = -10f                // Grenzhelligkeit (mag)
        var starsVisible = false
        var bgStars = 0f                    // Stärke der schwachen Hintergrundsterne
        var dayLight = 0f                   // 0 = Nacht, 1 = Tag (für Flugzeuge)
        var golden = 0f
        var cover = 0f
        var wet = false
        fun recycle() {
            cloudTile?.recycle(); cloudTile = null
            mask?.recycle(); mask = null
        }
    }

    /** Rechnet Himmelsrichtung/Höhe in Bildpunkte um (Horizont = Unterkante des Himmels). */
    private class Proj(val w: Int, val horizonY: Float, val viewAz: Double, hfov: Double, skyHeight: Float) {
        val ppd = (w / hfov).toFloat()   // Pixel pro Grad (waagrecht)
        // senkrecht: ein schmaler Himmelsstreifen soll trotzdem mind. 35° Höhe zeigen
        val ppdY = min(ppd, skyHeight / 35f).coerceAtLeast(0.5f)
        fun dAz(az: Double): Double = ((az - viewAz + 540.0) % 360.0) - 180.0
        fun x(az: Double): Float = w / 2f + dAz(az).toFloat() * ppd
        fun y(alt: Double): Float = horizonY - alt.toFloat() * ppdY
    }

    // Stützstellen: Sonnenhöhe -> Himmel oben, Himmel unten, Farbfaktor für die Landschaft
    private class Key(val elev: Double, val top: Int, val bottom: Int, val r: Float, val g: Float, val b: Float)

    private val keys = listOf(
        // Nacht bewusst nicht zu dunkel: Landschaft soll als Hintergrund erkennbar bleiben
        Key(-90.0, 0x02040B, 0x060B1A, 0.50f, 0.56f, 0.72f),
        Key(-18.0, 0x02040B, 0x070D1E, 0.50f, 0.56f, 0.72f),
        Key(-12.0, 0x050A1C, 0x111D40, 0.53f, 0.58f, 0.73f),
        Key(-6.0, 0x0F1C45, 0x3D4275, 0.62f, 0.63f, 0.75f),
        Key(-2.0, 0x22356C, 0xD8755C, 0.75f, 0.68f, 0.70f),
        Key(2.0, 0x3461A8, 0xF6A86C, 0.92f, 0.80f, 0.72f),
        Key(8.0, 0x3A78C9, 0xC2DAEF, 1.00f, 0.95f, 0.90f),
        Key(20.0, 0x2C6ED6, 0x9DCBF6, 1.00f, 1.00f, 1.00f),
        Key(90.0, 0x1E62D6, 0x8CC2F7, 1.03f, 1.03f, 1.03f)
    )

    /**
     * @param softness 0..100: so viel Prozent der Himmelshöhe werden nach unten hin
     *                 weich ins Originalbild übergeblendet (gut für dunstige Bilder).
     */
    fun render(
        original: Bitmap, polygon: List<PointF>, scene: Scene,
        softness: Int = 0, structure: Int = 50, haze: Int = 0, keepColors: Int = 0,
        live: LiveLayers? = null, cloudOpacity: Int = 85
    ): Bitmap {
        val w = original.width
        val h = original.height
        val e = scene.elevation
        val wx = scene.weather

        // ---- Grundfarben nach Sonnenstand ----
        val i = keys.indexOfLast { it.elev <= e }.coerceIn(0, keys.size - 2)
        val k0 = keys[i]
        val k1 = keys[i + 1]
        val t = ((e - k0.elev) / (k1.elev - k0.elev)).toFloat().coerceIn(0f, 1f)
        var top = lerpColor(k0.top, k1.top, t)
        var bottom = lerpColor(k0.bottom, k1.bottom, t)
        var gr = lerp(k0.r, k1.r, t)
        var gg = lerp(k0.g, k1.g, t)
        var gb = lerp(k0.b, k1.b, t)

        // ---- Wetter: Bewölkung macht den Himmel grau ----
        val cover = (wx?.cloudCover ?: 0) / 100f
        val wet = wx != null && (wx.isRain || wx.isDrizzle || wx.isSnow || wx.isThunder)
        var gray = (cover * 0.85f + if (wet) 0.2f else 0f).coerceIn(0f, 1f)
        if (wx?.isFog == true) gray = 1f
        val darkness = when {
            wx?.isThunder == true -> 0.55f
            wx?.isRain == true -> 0.72f
            wx?.isSnow == true -> 0.92f
            wx?.isDrizzle == true -> 0.8f
            else -> 0.9f
        }
        if (gray > 0f) {
            top = lerpColor(top, grayOf(top, darkness * 1.1f), gray)
            bottom = lerpColor(bottom, grayOf(bottom, darkness), gray)
            val nightNow = ramp(e, -3.0, -14.0)
            val dim = 1f - 0.22f * gray * (1.6f - darkness) * (1f - 0.6f * nightNow)
            gr *= dim; gg *= dim; gb *= dim
            // Graue Tage: Landschaft entsättigt leicht in Richtung Blau
            gb = lerp(gb, (gr + gg + gb) / 3f, 0.3f * gray)
        }

        val night = ramp(e, -3.0, -14.0)       // 0 = Tag, 1 = tiefe Nacht
        // Originalfarben: 0 = volle Wirkung, 1 = Foto-Farben bleiben weitgehend erhalten
        val keep = (keepColors / 100f).coerceIn(0f, 1f)
        run {
            // Farbstich abschwächen (Helligkeit bleibt), Nachts aber etwas Blau behalten
            val avg = (gr + gg + gb) / 3f
            val k = keep * (0.85f - 0.35f * night)
            gr = lerp(gr, avg, k); gg = lerp(gg, avg, k); gb = lerp(gb, avg, k)
        }
        val golden = 1f - ramp(kotlin.math.abs(e - 1.0), 0.0, 9.0) // um Sonnenauf-/untergang

        // ---- 1) Landschaft einfärben ----
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val cm = ColorMatrix(
            floatArrayOf(
                gr, 0f, 0f, 0f, 8f * night,
                0f, gg, 0f, 0f, 11f * night,
                0f, 0f, gb, 0f, 20f * night,
                0f, 0f, 0f, 1f, 0f
            )
        )
        // Nachts etwas Sättigung rausnehmen (Augen sehen nachts weniger Farbe)
        val sat = ColorMatrix().apply { setSaturation(lerp(1f - 0.55f * night, 1.08f, keep)) }
        cm.postConcat(sat)
        canvas.drawBitmap(original, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        })

        // ---- 2) Himmel malen ----
        if (polygon.size >= 3) {
            val path = Path()
            polygon.forEachIndexed { idx, p ->
                val x = p.x * w
                val y = p.y * h
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            val bounds = RectF()
            path.computeBounds(bounds, true)
            if (bounds.height() < 2f) bounds.bottom = bounds.top + 2f

            val sky = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val sc = Canvas(sky)
            val proj = Proj(w, bounds.bottom, scene.viewAz, scene.hfov, bounds.height())
            val moon = Astro.moon(scene.lat, scene.lon, scene.timeMillis)

            // Mondlicht hellt einen klaren Nachthimmel etwas auf
            if (night > 0.3f && moon.pos.alt > 0) {
                val ml = (moon.illum * night * min(1.0, moon.pos.alt / 20.0) * 0.45).toFloat() * (1f - 0.6f * gray)
                top = lerpColor(top, 0x18243F, ml)
                bottom = lerpColor(bottom, 0x2C3C5E, ml)
            }

            // Verlauf
            val grad = Paint().apply {
                shader = LinearGradient(
                    0f, bounds.top, 0f, bounds.bottom,
                    intArrayOf(top, lerpColor(top, bottom, 0.55f), bottom),
                    floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            }
            sc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), grad)

            val clearness = (1f - cover).pow(1.5f) * if (wet || wx?.isFog == true) 0.2f else 1f

            // Sterne & Planeten an ihrer echten Position
            val starsOn = night > 0.02f && clearness > 0.02f
            if (starsOn && live?.wantLiveStars != true) drawStars(sc, bounds, proj, scene, night, clearness)
            if (live != null) {
                live.viewAz = scene.viewAz
                live.ppd = proj.ppd
                live.ppdY = proj.ppdY
                live.horizonY = proj.horizonY
                live.starLimit = limitMag(night, clearness)
                live.starsVisible = starsOn
                live.bgStars = if (night > 0.6f) (night - 0.6f) / 0.4f * clearness else 0f
                live.dayLight = 1f - ramp(e, -1.0, -6.0)
                live.golden = golden
                live.cover = cover
                live.wet = wet || wx?.isFog == true
            }

            // Mond (auch tagsüber blass sichtbar)
            val moonVis = (1f - cover).pow(0.8f) * (if (wet || wx?.isFog == true) 0.15f else 1f)
            if (moon.pos.alt > -1 && moonVis > 0.05f) drawMoon(sc, bounds, proj, scene, moon, night, moonVis)

            // Sonne
            if (e > -1.5 && cover < 0.85f && !wet) {
                drawSun(sc, bounds, proj, scene, (1f - cover / 0.85f).coerceIn(0f, 1f), golden)
            }

            // Satelliten (ISS) – nur wenn sie von der Sonne angestrahlt wird und es bei uns dunkel ist
            if (scene.iss != null && e < -4 && clearness > 0.2f) drawIss(sc, bounds, proj, scene, night * clearness)

            // Wolken: eigene Ebene (im Live-Modus bewegt, sonst nach dem Himmel aufgelegt)
            var staticTile: Bitmap? = null
            if (cover > 0.05f || wx?.isFog == true) {
                val tile = makeCloudTile(bounds, cover, night, golden, darkness, wx, scene.timeMillis, live != null)
                if (live != null) live.cloudTile = tile else staticTile = tile
            }

            // Nebel = milchiger Schleier
            if (wx?.isFog == true) {
                sc.drawColor(Color.argb(150, 190, 196, 204).dimBy(1f - 0.75f * night))
            }

            // Bewölkte Nacht: Wolken werden von unten vom Stadtlicht leicht warm angeleuchtet
            if (night > 0.3f && cover > 0.4f) {
                val a = (night * ((cover - 0.4f) / 0.6f) * 85).toInt().coerceIn(0, 255)
                sc.drawRect(bounds, Paint().apply {
                    shader = LinearGradient(0f, bounds.top, 0f, bounds.bottom,
                        Color.TRANSPARENT, Color.argb(a, 150, 110, 85), Shader.TileMode.CLAMP)
                })
            }

            // Helligkeits-Struktur des Originalfotos übernehmen -> wirkt wie ein echtes Foto
            // bei hohen "Originalfarben" scheint das Foto ohnehin durch -> Struktur nicht doppelt verstärken
            val structAmt = structure / 100f * (1f - 0.75f * keep)
            if (structAmt > 0.01f) drawStructure(sc, original, bounds, structAmt)

            // Maske mit weicher Kante (ARGB, Deckkraft im Alphakanal)
            val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val mc = Canvas(mask)
            val feather = max(2f, min(w, h) * 0.006f)
            mc.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                maskFilter = BlurMaskFilter(feather, BlurMaskFilter.Blur.NORMAL)
            })
            // Weicher Übergang: unterer Teil des Himmels läuft stufenlos ins Originalbild aus.
            // Direkt pro Pixelzeile gerechnet -> funktioniert auf jedem Gerät gleich.
            if (softness > 0) {
                val fadeH = max(1f, bounds.height() * (softness.coerceIn(0, 100) / 100f))
                val fadeTop = bounds.bottom - fadeH
                val row = IntArray(w)
                val yStart = fadeTop.toInt().coerceIn(0, h - 1)
                for (y in yStart until h) {
                    val tt = ((y - fadeTop) / fadeH).coerceIn(0f, 1f)
                    val f = 1f - tt * tt * (3f - 2f * tt)
                    mask.getPixels(row, 0, w, 0, y, w, 1)
                    for (x in 0 until w) {
                        val al = row[x] ushr 24
                        row[x] = ((al * f).toInt().coerceIn(0, 255)) shl 24
                    }
                    mask.setPixels(row, 0, w, 0, y, w, 1)
                }
            }
            sc.drawBitmap(mask, 0f, 0f, Paint().apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            })
            // Bei "Originalfarben" scheint das Foto durch Himmel und Wolken durch (wie ein Schleier)
            val skyAlpha = (255 * (1f - 0.8f * keep)).toInt()
            // Wolken-Deckkraft hat einen eigenen Regler
            val cloudAlpha = (255 * cloudOpacity.coerceIn(0, 100) / 100f).toInt()
            canvas.drawBitmap(sky, 0f, 0f, Paint().apply { alpha = skyAlpha })
            if (staticTile != null) {
                sky.eraseColor(Color.TRANSPARENT)
                sc.drawBitmap(staticTile, null, bounds, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
                sc.drawBitmap(mask, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
                canvas.drawBitmap(sky, 0f, 0f, Paint().apply { alpha = cloudAlpha })
                staticTile.recycle()
            }
            sky.recycle()
            if (live != null) {
                live.mask = mask
                live.skyRect = RectF(bounds)
                live.skyAlpha = skyAlpha
                live.cloudAlpha = cloudAlpha
            } else {
                mask.recycle()
            }

            // Dunst: Himmelsfarbe zieht sich in die fernen Berge unter dem Horizont (Luftperspektive)
            if (haze > 0) {
                val hz = h * (haze.coerceIn(0, 100) / 100f)
                val y0 = bounds.bottom - bounds.height() * 0.15f
                val hazeCol = lerpColor(bottom, top, 0.15f)
                val hk = 1f - 0.7f * keep
                canvas.drawRect(0f, y0, w.toFloat(), bounds.bottom + hz, Paint().apply {
                    shader = LinearGradient(0f, y0, 0f, bounds.bottom + hz,
                        intArrayOf(hazeCol.withAlpha(0), hazeCol.withAlpha((150 * hk).toInt()), hazeCol.withAlpha((90 * hk).toInt()), hazeCol.withAlpha(0)),
                        floatArrayOf(0f, 0.18f, 0.55f, 1f), Shader.TileMode.CLAMP)
                })
            }
        }

        // ---- 3) Niederschlag übers ganze Bild (im Live-Modus animiert) ----
        if (live != null) {
            live.night = night
            live.windKmh = (wx?.windSpeed ?: 10.0).toFloat()
            if (wx != null) {
                live.rain = wx.isRain || wx.isDrizzle || wx.isThunder
                live.snow = wx.isSnow
                live.thunder = wx.isThunder
                live.rainIntensity = when {
                    wx.isThunder -> 1f
                    wx.isDrizzle -> 0.35f
                    else -> (0.4f + wx.precipitation.toFloat() / 4f).coerceIn(0.4f, 1f)
                }
            }
        }
        if (wx != null) {
            if (live == null && (wx.isRain || wx.isDrizzle || wx.isThunder)) drawRain(canvas, w, h, wx, night, scene.timeMillis)
            if (live == null && wx.isSnow) drawSnow(canvas, w, h, wx, scene.timeMillis)
            if (wx.isFog) canvas.drawColor(Color.argb(55, 200, 205, 212).dimBy(1f - 0.75f * night))
        }
        return out
    }

    // ------------------------------------------------------------------

    /** Grenzhelligkeit: wie schwache Sterne man bei dieser Dunkelheit noch sieht. */
    private fun limitMag(night: Float, clearness: Float): Float =
        -3.5f + 8.0f * night * (0.4f + 0.6f * clearness)

    private fun drawStars(c: Canvas, b: RectF, p: Proj, scene: Scene, night: Float, clearness: Float) {
        val base = min(b.width(), b.height())
        val limit = limitMag(night, clearness)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val twinkle = Random(scene.timeMillis / 900_000)

        // Schwache Hintergrundsterne (zufällig, aber fest) – nur in richtig dunkler Nacht
        if (night > 0.6f) {
            val rnd = Random(4242)
            val count = ((b.width() * b.height()) / 3500f).toInt().coerceIn(30, 600)
            val f = (night - 0.6f) / 0.4f * clearness
            for (n in 0 until count) {
                val x = b.left + rnd.nextFloat() * b.width()
                val y = b.top + rnd.nextFloat() * b.height()
                val fade = 1f - 0.7f * ((y - b.top) / b.height())
                val a = f * fade * (0.15f + 0.3f * rnd.nextFloat()) * (0.7f + 0.3f * twinkle.nextFloat())
                paint.color = Color.argb((a * 255).toInt().coerceIn(0, 255), 235, 240, 255)
                c.drawCircle(x, y, max(0.6f, base * 0.0009f), paint)
            }
        }

        // Echte Sterne + Planeten
        val bodies = Astro.stars(scene.lat, scene.lon, scene.timeMillis) +
            Astro.planets(scene.lat, scene.lon, scene.timeMillis)
        for (body in bodies) {
            val alt = body.pos.alt
            if (alt < 0.5) continue
            val x = p.x(body.pos.az)
            val y = p.y(alt)
            if (x < b.left - 20 || x > b.right + 20 || y < b.top - 20 || y > b.bottom + 20) continue
            // Atmosphäre schwächt Licht in Horizontnähe
            val airmass = 1.0 / kotlin.math.sin((alt + 244.0 / (165.0 + 47.0 * alt.pow(1.1))) * Math.PI / 180.0)
            val mag = body.mag + (0.25 * (airmass - 1)).toFloat()
            if (mag > limit) continue
            val strength = ((limit - mag) / 2.5f).coerceIn(0f, 1f)
            val bright = (2.5f - mag).coerceAtLeast(0f)
            val r = max(0.9f, base * (0.0011f + 0.0009f * bright))
            val tw = if (body.name.isEmpty()) 0.8f + 0.2f * twinkle.nextFloat() else 1f // Planeten funkeln nicht
            // Schein um helle Objekte
            if (mag < 1.2f) {
                val gr = r * (4f + bright)
                paint.shader = RadialGradient(x, y, gr,
                    body.color.withAlpha((90 * strength).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                c.drawCircle(x, y, gr, paint)
                paint.shader = null
            }
            paint.color = body.color.withAlpha((255 * strength * tw).toInt())
            c.drawCircle(x, y, r, paint)
        }
    }

    private fun drawMoon(
        c: Canvas, b: RectF, p: Proj, scene: Scene, moon: Astro.MoonInfo, night: Float, vis: Float
    ) {
        val x = p.x(moon.pos.az)
        val y = p.y(moon.pos.alt)
        val base = min(b.width(), b.height())
        val r = max(p.ppd * 0.7f, base * 0.03f)
        if (x < b.left - r || x > b.right + r || y < b.top - r || y > b.bottom + r) return

        // tagsüber blass, nachts hell
        val strength = vis * (0.45f + 0.55f * night)

        // Schein (nur nachts, je nach Mondphase)
        if (night > 0.2f) {
            val gr = r * (5f + 5f * moon.illum.toFloat())
            c.drawCircle(x, y, gr, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(x, y, gr,
                    Color.argb((95 * night * vis * moon.illum).toInt().coerceIn(0, 255), 205, 218, 255),
                    Color.TRANSPARENT, Shader.TileMode.CLAMP)
            })
        }

        // Richtung zur Sonne in Bildkoordinaten -> dort ist die helle Seite
        val sun = Astro.sun(scene.lat, scene.lon, scene.timeMillis)
        val sx = w2(p, sun.az, moon.pos.az)
        val sy = p.y(sun.alt)
        val angle = Math.toDegrees(kotlin.math.atan2((sy - y).toDouble(), (sx - x).toDouble())).toFloat()

        val k = moon.illum.toFloat().coerceIn(0f, 1f)
        val lit = Path()
        // heller Rand (Halbkreis zur Sonne hin)
        val steps = 40
        for (s in 0..steps) {
            val t = -90.0 + 180.0 * s / steps
            val px = (r * kotlin.math.cos(Math.toRadians(t))).toFloat()
            val py = (r * kotlin.math.sin(Math.toRadians(t))).toFloat()
            if (s == 0) lit.moveTo(px, py) else lit.lineTo(px, py)
        }
        // Schattengrenze (Ellipse) zurück
        for (s in steps downTo 0) {
            val t = -90.0 + 180.0 * s / steps
            val px = ((1f - 2f * k) * r * kotlin.math.cos(Math.toRadians(t))).toFloat()
            val py = (r * kotlin.math.sin(Math.toRadians(t))).toFloat()
            lit.lineTo(px, py)
        }
        lit.close()

        c.save()
        c.translate(x, y)
        c.rotate(angle)
        // Erdschein: dunkle Seite schwach sichtbar
        c.drawCircle(0f, 0f, r, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((40 * strength * night).toInt().coerceIn(0, 255), 120, 130, 160)
        })
        val dayTint = lerpColor(0xF4F1E4, 0xFFFFFF, 1f - night)
        c.drawPath(lit, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(r * 0.2f, -r * 0.2f, r * 1.2f,
                dayTint.withAlpha((255 * strength).toInt()),
                lerpColor(dayTint, 0xC9C2AE, 0.5f).withAlpha((235 * strength).toInt()),
                Shader.TileMode.CLAMP)
        })
        // ein paar "Meere" für Struktur
        val mare = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((38 * strength).toInt().coerceIn(0, 255), 90, 90, 100)
        }
        c.clipPath(lit)
        c.rotate(-angle)
        c.drawCircle(-r * 0.25f, -r * 0.3f, r * 0.28f, mare)
        c.drawCircle(r * 0.2f, -r * 0.1f, r * 0.22f, mare)
        c.drawCircle(-r * 0.05f, r * 0.3f, r * 0.2f, mare)
        c.restore()
    }

    /** x-Position der Sonne, aber ohne Umbruch relativ zum Mond (für die Richtung der hellen Seite). */
    private fun w2(p: Proj, sunAz: Double, moonAz: Double): Float {
        val d = ((sunAz - moonAz + 540.0) % 360.0) - 180.0
        return p.x(moonAz) + d.toFloat() * p.ppd
    }

    private fun drawSun(c: Canvas, b: RectF, p: Proj, scene: Scene, vis: Float, golden: Float) {
        val base = min(b.width(), b.height())
        val r = max(p.ppd * 0.8f, base * 0.035f)
        var x = p.x(scene.sunAz)
        val y = p.y(scene.elevation)
        val core = lerpColor(0xFFF8E6, 0xFFB25A, golden)
        val halo = lerpColor(0xFFF2C8, 0xFF8A4A, golden)

        val inView = x > b.left - r && x < b.right + r && y > b.top - r * 4
        if (!inView) {
            // Sonne außerhalb des Bildes: nur Leuchten am Rand auf ihrer Seite, wenn sie tief steht
            if (scene.elevation > 20) return
            x = if (p.dAz(scene.sunAz) < 0) b.left else b.right
            val a = (vis * 0.6f * (1f - (kotlin.math.abs(p.dAz(scene.sunAz)).toFloat() / 180f))).coerceIn(0f, 1f)
            val gr = b.width() * 0.8f
            c.drawCircle(x, y.coerceAtMost(b.bottom), gr, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(x, y.coerceAtMost(b.bottom), gr,
                    halo.withAlpha((120 * a).toInt()), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            })
            return
        }

        val glowR = r * (7f + 7f * golden)
        c.drawCircle(x, y, glowR, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(x, y, glowR,
                intArrayOf(halo.withAlpha((190 * vis).toInt()), halo.withAlpha((50 * vis).toInt()), Color.TRANSPARENT),
                floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
        })
        c.drawCircle(x, y, r, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(x, y, r,
                intArrayOf(core.withAlpha((255 * vis).toInt()), core.withAlpha((215 * vis).toInt())),
                null, Shader.TileMode.CLAMP)
        })
        // Warmes Band am Horizont bei Sonnenauf-/untergang
        if (golden > 0.05f) {
            val bandTop = b.bottom - b.height() * 0.45f
            c.drawRect(b.left, bandTop, b.right, b.bottom, Paint().apply {
                shader = LinearGradient(0f, bandTop, 0f, b.bottom,
                    Color.TRANSPARENT, halo.withAlpha((90 * golden * vis).toInt()), Shader.TileMode.CLAMP)
            })
        }
    }

    private fun drawIss(c: Canvas, b: RectF, p: Proj, scene: Scene, strength: Float) {
        val iss = scene.iss ?: return
        if (!iss.sunlit) return
        if (kotlin.math.abs(scene.timeMillis - iss.time) > 5 * 60_000L) return // veraltet
        val p1 = Astro.satellitePos(scene.lat, scene.lon, iss.lat, iss.lon, iss.altKm)
        if (p1.alt < 8) return
        val p2 = Astro.satellitePos(scene.lat, scene.lon, iss.lat2, iss.lon2, iss.alt2Km)
        val x1 = p.x(p1.az); val y1 = p.y(p1.alt)
        if (x1 < b.left || x1 > b.right || y1 < b.top || y1 > b.bottom) return
        val dAz = (((p2.az - p1.az + 540.0) % 360.0) - 180.0).toFloat()
        val x2 = x1 + dAz * p.ppd
        val y2 = p.y(p2.alt)
        val base = min(b.width(), b.height())

        // Spur (woher sie kommt)
        val tx = x1 - (x2 - x1) * 1.5f
        val ty = y1 - (y2 - y1) * 1.5f
        c.drawLine(tx, ty, x1, y1, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = max(1.5f, base * 0.003f)
            strokeCap = Paint.Cap.ROUND
            shader = LinearGradient(tx, ty, x1, y1, Color.TRANSPARENT,
                Color.argb((200 * strength).toInt().coerceIn(0, 255), 255, 255, 255), Shader.TileMode.CLAMP)
        })
        val r = max(2f, base * 0.0045f)
        c.drawCircle(x1, y1, r * 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(x1, y1, r * 4f,
                Color.argb((150 * strength).toInt().coerceIn(0, 255), 255, 255, 240), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        })
        c.drawCircle(x1, y1, r, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((255 * strength).toInt().coerceIn(0, 255), 255, 255, 250)
        })
        c.drawText("ISS", x1 + r * 3f, y1 - r * 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb((170 * strength).toInt().coerceIn(0, 255), 220, 230, 255)
            textSize = max(10f, base * 0.022f)
        })
    }

    /** Wolkentextur für den Himmelsbereich b. tileable = links/rechts nahtlos (für Animation). */
    private fun makeCloudTile(
        b: RectF, cover: Float, night: Float, golden: Float,
        darkness: Float, wx: Weather?, time: Long, tileable: Boolean
    ): Bitmap {
        // ---- Farben nach Licht ----
        var lit = 0xF4F6FA
        lit = lerpColor(lit, 0xFFB894, golden * 0.8f)          // Abendrot von unten
        lit = lerpColor(lit, 0x3A3C48, night)                  // Nacht: dunkles Grau
        lit = lerpColor(lit, grayOf(lit, darkness), (1f - darkness) * 2.2f)
        val shade = lerpColor(lit, if (night > 0.5f) 0x0E1018 else 0x4A5262, 0.55f)
        // Oberseite der Wolken etwas heller / bei Sonnenuntergang rosa
        val rim = lerpColor(lerpColor(lit, 0xFFFFFF, 0.25f * (1f - night)), 0xFF9C8A, golden * 0.5f)

        // ---- Rauschen in niedriger Auflösung berechnen, dann weich hochskalieren ----
        val aspect = b.height() / max(1f, b.width())
        val cw = 360
        val ch = (cw * aspect).toInt().coerceIn(56, 760)
        val px = IntArray(cw * ch)

        val wind = ((wx?.windSpeed ?: 10.0).coerceIn(2.0, 60.0)).toFloat()
        val minutes = (time / 60_000L % 1_000_000L).toFloat()
        val driftX = if (tileable) 0f else minutes * wind * 0.00025f
        val driftY = minutes * 0.00004f

        // Bedeckungsgrad -> Schwelle; bei 100 % fast alles Wolke, aber mit Struktur
        val th = lerp(0.78f, 0.18f, cover)
        val scale = 3.2f

        for (y in 0 until ch) {
            val v = y / ch.toFloat()                 // 0 oben, 1 Horizont
            // Perspektive: zum Horizont hin weiter weg -> Wolken flacher und kleiner
            val depth = 1f / (1.4f - v)
            val xs = scale * 1.3f * depth.pow(0.55f)
            val sy = scale * (1.3f * v + 0.9f * depth) + driftY
            for (x in 0 until cw) {
                val u = x / cw.toFloat()
                val sx = (u - 0.5f) * xs + driftX
                val d = if (!tileable) {
                    density(sx, sy)
                } else {
                    // nahtlos: mit der um eine Breite verschobenen Kopie überblenden (Varianz bleibt erhalten)
                    val a1 = 1f - u
                    val a2 = u
                    val n = kotlin.math.sqrt(a1 * a1 + a2 * a2)
                    0.5f + ((density(sx, sy) - 0.5f) * a1 + (density(sx - xs, sy) - 0.5f) * a2) / n
                }
                // Dichte -> Deckkraft
                var a = smooth(th - 0.06f, th + 0.13f, d)
                // Am Horizont verdichten sich Wolken optisch
                a = min(1f, a + cover * 0.35f * v * v)
                if (a <= 0.003f) { px[y * cw + x] = 0; continue }
                // Dicke Stellen dunkler, Ränder heller
                val thick = smooth(th + 0.04f, th + 0.36f, d)
                var col = lerpColor(rim, lit, smooth(0f, 0.25f, a))
                col = lerpColor(col, shade, thick * (0.7f + 0.2f * cover))
                val alpha = (a * (if (night > 0.5f) 0.95f else 1f) * 255).toInt()
                px[y * cw + x] = col.withAlpha(alpha)
            }
        }
        return Bitmap.createBitmap(px, cw, ch, Bitmap.Config.ARGB_8888)
    }

    /** Wolkendichte an einer Stelle – Domain-Warping für fransige, natürliche Formen. */
    private fun density(sx: Float, sy: Float): Float {
        val wx1 = fbm(sx + 3.1f, sy + 1.7f, 2)
        val wy1 = fbm(sx - 2.3f, sy + 5.9f, 2)
        return fbm(sx + 0.75f * wx1, sy + 0.75f * wy1, 5)
    }

    /** Überträgt die Hell/Dunkel-Details des Fotos (Overlay) auf den neuen Himmel. */
    private fun drawStructure(c: Canvas, original: Bitmap, b: RectF, amount: Float) {
        // mittlere Helligkeit im Himmelsbereich bestimmen
        val l = b.left.toInt().coerceIn(0, original.width - 1)
        val t = b.top.toInt().coerceIn(0, original.height - 1)
        val rw = b.width().toInt().coerceIn(1, original.width - l)
        val rh = b.height().toInt().coerceIn(1, original.height - t)
        val region = Bitmap.createBitmap(original, l, t, rw, rh)
        val tiny = Bitmap.createScaledBitmap(region, 24, 24, true)
        var sum = 0.0
        for (yy in 0 until 24) for (xx in 0 until 24) {
            val p = tiny.getPixel(xx, yy)
            sum += 0.3 * Color.red(p) + 0.59 * Color.green(p) + 0.11 * Color.blue(p)
        }
        if (region !== original) region.recycle()
        tiny.recycle()
        val mean = (sum / (24 * 24)).toFloat()

        // Details = Abweichung von der mittleren Helligkeit.
        // Hellere Stellen werden addiert, dunklere multipliziert -> klappt bei hellem UND dunklem Himmel.
        val k = 1.4f * amount.coerceIn(0f, 1f)
        val g = floatArrayOf(0.3f * k, 0.59f * k, 0.11f * k)
        val addM = ColorMatrix(floatArrayOf(
            g[0], g[1], g[2], 0f, -mean * k,
            g[0], g[1], g[2], 0f, -mean * k,
            g[0], g[1], g[2], 0f, -mean * k,
            0f, 0f, 0f, 0f, 255f
        ))
        val mulM = ColorMatrix(floatArrayOf(
            g[0], g[1], g[2], 0f, 255f - mean * k,
            g[0], g[1], g[2], 0f, 255f - mean * k,
            g[0], g[1], g[2], 0f, 255f - mean * k,
            0f, 0f, 0f, 0f, 255f
        ))
        c.save()
        c.clipRect(b)
        c.drawBitmap(original, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(addM)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        })
        c.drawBitmap(original, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(mulM)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
        })
        c.restore()
    }

    // ---------------- Rauschen ----------------

    private fun hash(ix: Int, iy: Int): Float {
        var h = ix * 374761393 + iy * 668265263
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0x7fffffff) / 2147483647f
    }

    private fun valueNoise(x: Float, y: Float): Float {
        val xf = kotlin.math.floor(x)
        val yf = kotlin.math.floor(y)
        val ix = xf.toInt()
        val iy = yf.toInt()
        val fx = x - xf
        val fy = y - yf
        val ux = fx * fx * (3f - 2f * fx)
        val uy = fy * fy * (3f - 2f * fy)
        val a = hash(ix, iy)
        val bb = hash(ix + 1, iy)
        val cc = hash(ix, iy + 1)
        val dd = hash(ix + 1, iy + 1)
        return lerp(lerp(a, bb, ux), lerp(cc, dd, ux), uy)
    }

    private fun fbm(x: Float, y: Float, octaves: Int): Float {
        var sum = 0f
        var amp = 0.5f
        var fx = x
        var fy = y
        var norm = 0f
        for (o in 0 until octaves) {
            sum += amp * valueNoise(fx, fy)
            norm += amp
            // leicht drehen, damit kein Gitter sichtbar ist
            val nx = fx * 1.6f + fy * 1.2f
            val ny = -fx * 1.2f + fy * 1.6f
            fx = nx + 17.3f
            fy = ny + 9.1f
            amp *= 0.5f
        }
        return sum / norm
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun drawRain(c: Canvas, w: Int, h: Int, wx: Weather, night: Float, time: Long) {
        val rnd = Random(time / 900_000)
        val intensity = when {
            wx.isThunder -> 1f
            wx.isDrizzle -> 0.35f
            else -> (0.4f + wx.precipitation.toFloat() / 4f).coerceIn(0.4f, 1f)
        }
        val count = (w * h / 9000f * intensity).toInt().coerceAtMost(1400)
        val len = h * 0.035f
        val slant = (wx.windSpeed.toFloat() / 40f).coerceIn(0f, 0.6f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = max(1f, w / 900f)
            strokeCap = Paint.Cap.ROUND
        }
        val col = lerpColor(0xD8E2EE, 0x8090A8, night)
        for (n in 0 until count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val l = len * (0.5f + rnd.nextFloat())
            p.color = col.withAlpha((40 + rnd.nextInt(60)))
            c.drawLine(x, y, x - l * slant, y + l, p)
        }
    }

    private fun drawSnow(c: Canvas, w: Int, h: Int, wx: Weather, time: Long) {
        val rnd = Random(time / 900_000)
        val count = (w * h / 7000f).toInt().coerceAtMost(1500)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = min(w, h)
        for (n in 0 until count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val r = base * (0.0015f + 0.004f * rnd.nextFloat().pow(2f))
            p.color = Color.argb(120 + rnd.nextInt(120), 255, 255, 255)
            c.drawCircle(x, y, r, p)
        }
    }

    // ---------------- Hilfsfunktionen ----------------

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun ramp(v: Double, from: Double, to: Double): Float =
        ((v - from) / (to - from)).toFloat().coerceIn(0f, 1f)

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val r = ((a shr 16 and 0xFF) + ((b shr 16 and 0xFF) - (a shr 16 and 0xFF)) * tt).toInt()
        val g = ((a shr 8 and 0xFF) + ((b shr 8 and 0xFF) - (a shr 8 and 0xFF)) * tt).toInt()
        val bl = ((a and 0xFF) + ((b and 0xFF) - (a and 0xFF)) * tt).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Grau mit gleicher Helligkeit, leicht bläulich, mal Faktor. */
    private fun grayOf(c: Int, factor: Float): Int {
        val r = c shr 16 and 0xFF
        val g = c shr 8 and 0xFF
        val b = c and 0xFF
        val lum = (0.3f * r + 0.59f * g + 0.11f * b)
        val v = (lum * 0.55f + 150f * (lum / 255f).pow(0.4f) * 0.45f) * factor
        val gv = v.toInt().coerceIn(0, 255)
        return (0xFF shl 24) or ((gv * 0.96f).toInt() shl 16) or (gv shl 8) or (gv * 1.04f).toInt().coerceAtMost(255)
    }

    private fun Int.withAlpha(a: Int): Int = (this and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun Int.dimBy(f: Float): Int {
        val a = Color.alpha(this)
        val r = (Color.red(this) * f).toInt()
        val g = (Color.green(this) * f).toInt()
        val b = (Color.blue(this) * f).toInt()
        return Color.argb(a, r, g, b)
    }
}
